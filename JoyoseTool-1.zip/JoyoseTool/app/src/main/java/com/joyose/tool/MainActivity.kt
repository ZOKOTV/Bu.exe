package com.joyose.tool

import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val pkg = "com.xiaomi.joyose"
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var buttons: List<Button>

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { connect() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    override fun onResume() {
        super.onResume()
        connect()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }

    // Tu dong ket noi: xin quyen Shizuku ngay khi co the
    private fun connect() {
        if (Shizuku.pingBinder() && !hasPerm() && !Shizuku.shouldShowRequestPermissionRationale()) {
            Shizuku.requestPermission(100)
        }
        refresh()
    }

    private fun hasPerm() = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun refresh() {
        val ok = Shizuku.pingBinder() && hasPerm()
        status.text = when {
            !Shizuku.pingBinder() -> "Shizuku: CHUA CHAY (mo Shizuku va khoi dong)"
            !hasPerm() -> "Shizuku: dang cho cap quyen..."
            else -> "Shizuku: DA KET NOI"
        }
        status.setTextColor(if (ok) Color.rgb(0, 130, 0) else Color.RED)
        buttons.forEach { it.isEnabled = ok }
    }

    private fun sh(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }

    private fun run(title: String, cmd: String) {
        log.text = "$title...\n"
        Thread {
            val r = try { sh(cmd) } catch (e: Throwable) { "Loi: ${e.message}" }
            runOnUiThread { log.text = "$title\n$r" }
        }.start()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        TextView(this).apply { text = "Joyose Tool"; textSize = 26f; root.addView(this) }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 16, 0, 32); root.addView(this) }

        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
            root.addView(this)
        }
        buttons = listOf(
            btn("Xoa Joyose") { run("Xoa Joyose", "pm uninstall --user 0 $pkg") },
            btn("Cai lai Joyose") { run("Cai lai Joyose", "pm install-existing --user 0 $pkg") },
            btn("Kiem tra trang thai") {
                log.text = "Dang kiem tra..."
                Thread {
                    val r = try {
                        val list = sh("pm list packages --user 0 $pkg")
                        val dump = sh("dumpsys package $pkg | grep -i 'installed='")
                        val installed = list.contains("package:$pkg")
                        (if (installed) "Joyose: DANG CAI" else "Joyose: DA BI GO") +
                            "\n\n[pm list]\n$list\n\n[dumpsys]\n$dump"
                    } catch (e: Throwable) { "Loi: ${e.message}" }
                    runOnUiThread { log.text = r }
                }.start()
            }
        )
        btn("Ket noi lai Shizuku") { connect() }.also { it.isEnabled = true }

        log = TextView(this).apply { textSize = 14f; gravity = Gravity.START; setPadding(0, 32, 0, 0) }
        root.addView(ScrollView(this).apply { addView(log) })
        setContentView(root)
    }
}
