package com.joyose.tool.admin

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : Activity() {

    private val BG = Color.parseColor("#0E1014")
    private val CARD = Color.parseColor("#181B22")
    private val FIELD = Color.parseColor("#262A33")
    private val TEXT = Color.parseColor("#F2F4FA")
    private val SUB = Color.parseColor("#A9B1C6")
    private val ACCENT = Color.parseColor("#6C8CFF")
    private val OK = Color.parseColor("#3DDC97")
    private val BAD = Color.parseColor("#FF6B6B")
    private val repo = "ZOKOTV/Bu.exe"

    private lateinit var prefs: SharedPreferences
    private lateinit var urlEt: EditText
    private lateinit var keyEt: EditText
    private lateinit var status: TextView
    private lateinit var out: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("admin", MODE_PRIVATE)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        if (urlEt.text.isNotBlank() && keyEt.text.isNotBlank()) refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun lp(w: Int, h: Int, t: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(0, dp(t), 0, dp(b)) }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(parent: LinearLayout) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(CARD, 22)
        setPadding(dp(18), dp(16), dp(18), dp(16))
        parent.addView(this, lp(-1, -2, b = 12))
    }

    private fun field(hint: String, value: String, password: Boolean) = EditText(this).apply {
        setText(value)
        this.hint = hint
        setHintTextColor(SUB)
        setTextColor(TEXT)
        textSize = 14f
        isSingleLine = true
        background = round(FIELD, 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(48), dp(18), dp(28))
        }
        root.addView(tv("tđ Admin", 30f, TEXT, true))
        root.addView(tv("Thống kê người dùng tđ.exe", 13f, SUB), lp(-2, -2, t = 2, b = 18))

        val c = card(root)
        c.addView(tv("Kết nối", 16f, TEXT, true), lp(-2, -2, b = 10))
        c.addView(tv("Địa chỉ Apps Script (kết thúc bằng /exec)", 12f, SUB), lp(-2, -2, b = 4))
        urlEt = field("https://script.google.com/macros/s/.../exec", prefs.getString("url", "") ?: "", false)
        c.addView(urlEt, lp(-1, -2, b = 10))
        c.addView(tv("Mã quản trị", 12f, SUB), lp(-2, -2, b = 4))
        keyEt = field("mã bạn đặt trong Apps Script", prefs.getString("key", "") ?: "", true)
        c.addView(keyEt, lp(-1, -2, b = 12))
        val btn = Button(this).apply {
            text = "Lưu và làm mới"
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            stateListAnimator = null
            setTextColor(Color.WHITE)
            background = round(ACCENT, 14)
            setOnClickListener {
                prefs.edit()
                    .putString("url", urlEt.text.toString().trim())
                    .putString("key", keyEt.text.toString().trim())
                    .apply()
                refresh()
            }
        }
        c.addView(btn, lp(-1, dp(50)))

        status = tv("", 13f, SUB)
        root.addView(status, lp(-2, -2, b = 12))
        out = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(out)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })
    }

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "td-admin")
        c.setRequestProperty("Accept", "application/json")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun refresh() {
        status.setTextColor(SUB)
        status.text = "Đang tải…"
        val base = urlEt.text.toString().trim()
        val key = keyEt.text.toString().trim()
        Thread {
            try {
                val json = get(base + (if (base.contains("?")) "&" else "?") +
                    "action=stats&key=" + URLEncoder.encode(key, "UTF-8"))
                val o = JSONObject(json)
                if (o.has("error")) throw Exception(o.getString("error") + " (sai mã quản trị?)")
                val dl = try { githubDownloads() } catch (e: Throwable) { null }
                runOnUiThread { render(o, dl) }
            } catch (e: Throwable) {
                runOnUiThread {
                    status.setTextColor(BAD)
                    status.text = "Lỗi: ${e.message}"
                }
            }
        }.start()
    }

    /** Tổng lượt tải td-exe.apk từ GitHub Releases (không cần khóa). */
    private fun githubDownloads(): Triple<Int, String, Int> {
        val arr = JSONArray(get("https://api.github.com/repos/$repo/releases?per_page=100"))
        var total = 0
        var latestTag = "-"
        var latestCount = 0
        for (i in 0 until arr.length()) {
            val rel = arr.getJSONObject(i)
            val assets = rel.getJSONArray("assets")
            var n = 0
            for (j in 0 until assets.length()) {
                val a = assets.getJSONObject(j)
                if (a.getString("name") == "td-exe.apk") n += a.getInt("download_count")
            }
            total += n
            if (i == 0) { latestTag = rel.getString("tag_name"); latestCount = n }
        }
        return Triple(total, latestTag, latestCount)
    }

    private fun tile(label: String, value: String, note: String = "") {
        val c = card(out)
        c.addView(tv(label, 12f, SUB))
        c.addView(tv(value, 34f, TEXT, true))
        if (note.isNotEmpty()) c.addView(tv(note, 11f, SUB), lp(-2, -2, t = 2))
    }

    private fun listCard(title: String, lines: List<String>) {
        val c = card(out)
        c.addView(tv(title, 14f, TEXT, true), lp(-2, -2, b = 8))
        lines.forEach { c.addView(tv(it, 13f, SUB), lp(-2, -2, b = 3)) }
    }

    private fun render(o: JSONObject, dl: Triple<Int, String, Int>?) {
        status.setTextColor(OK)
        status.text = "Đã cập nhật"
        out.removeAllViews()

        tile("Người dùng", o.optInt("users").toString(), "số mã ẩn danh khác nhau (cài lại app tạo mã mới)")
        tile("Hoạt động 7 ngày", o.optInt("active7").toString(), "người mở app trong 7 ngày qua")
        tile("Lượt truy cập hôm nay", o.optInt("opensToday").toString(), "${o.optInt("usersToday")} người")
        tile("Lượt truy cập 7 ngày", o.optInt("opens7").toString())
        tile("Tổng lượt truy cập", o.optInt("opens").toString(), "mỗi lần mở app tính một lượt")
        val users = o.optInt("users")
        val declines = o.optInt("declines")
        tile("Đã từ chối thống kê", declines.toString(), "${o.optInt("declines7")} trong 7 ngày qua")
        if (users + declines > 0) {
            tile("Tỉ lệ đồng ý (ước lượng)", "${users * 100 / (users + declines)}%",
                "đồng ý / (đồng ý + từ chối); cài lại app có thể đếm thêm")
        }

        val vers = o.optJSONObject("versions")
        if (vers != null && vers.length() > 0) {
            val keys = vers.keys().asSequence().toList().sortedByDescending { it.toIntOrNull() ?: 0 }
            listCard("Phiên bản đang dùng", keys.map { "v$it: ${vers.optInt(it)} người" })
        }

        val daily = o.optJSONArray("daily")
        if (daily != null && daily.length() > 0) {
            val lines = mutableListOf<String>()
            for (i in 0 until daily.length()) {
                val d = daily.getJSONObject(i)
                lines.add("${d.optString("d")}: ${d.optInt("n")} lượt")
            }
            listCard("7 ngày gần nhất", lines)
        }

        if (dl != null) {
            tile("Lượt tải APK (GitHub)", dl.first.toString(), "bản mới nhất ${dl.second}: ${dl.third} lượt tải")
        }
    }
}
