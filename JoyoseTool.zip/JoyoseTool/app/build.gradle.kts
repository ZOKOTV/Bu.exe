plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val verCode = (project.findProperty("verCode") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "com.joyose.tool"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.joyose.tool"
        minSdk = 24
        targetSdk = 34
        versionCode = verCode
        versionName = "1.$verCode"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("td.keystore")
            storeType = "pkcs12"
            storePassword = "android"
            keyAlias = "td"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
