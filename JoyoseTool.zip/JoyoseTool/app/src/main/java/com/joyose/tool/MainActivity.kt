package com.joyose.tool

import android.app.Activity
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val pkg = "com.xiaomi.joyose"
    private val hzList = listOf(90, 120, 144)

    private val BG = Color.parseColor("#0E1014")
    private val CARD = Color.parseColor("#181B22")
    private val CHIP = Color.parseColor("#262A33")
    private val TEXT = Color.parseColor("#ECEFF4")
    private val SUB = Color.parseColor("#9AA3B2")
    private val ACCENT = Color.parseColor("#6C8CFF")
    private val OK = Color.parseColor("#3DDC97")
    private val BAD = Color.parseColor("#FF6B6B")

    private lateinit var prefs: SharedPreferences
    private lateinit var dot: View
    private lateinit var shizukuText: TextView
    private lateinit var joyoseText: TextView
    private lateinit var perfSwitch: Switch
    private lateinit var log: TextView
    private val gated = mutableListOf<View>()
    private val chips = mutableListOf<TextView>()
    private var suppress = false

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { connect() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh(true) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("joyose_tool", MODE_PRIVATE)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    override fun onResume() {
        super.onResume()
        connect()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }

    // ---------- Shizuku ----------
    private fun connect() {
        if (Shizuku.pingBinder() && !hasPerm() && !Shizuku.shouldShowRequestPermissionRationale()) {
            Shizuku.requestPermission(100)
        }
        refresh(true)
    }

    private fun hasPerm() = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun refresh(checkJoyose: Boolean = false) {
        val running = Shizuku.pingBinder()
        val ok = running && hasPerm()
        dot.background = oval(if (ok) OK else BAD)
        shizukuText.text = when {
            !running -> "Shizuku chưa chạy — hãy mở Shizuku và khởi động"
            !hasPerm() -> "Đang chờ cấp quyền Shizuku…"
            else -> "Shizuku đã kết nối"
        }
        gated.forEach { it.isEnabled = ok; it.alpha = if (ok) 1f else 0.4f }
        suppress = true
        perfSwitch.isChecked = prefs.getBoolean("active", false)
        suppress = false
        updateChips()
        if (ok && checkJoyose) checkJoyoseStatus(false)
    }

    private fun sh(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }

    private fun bg(title: String, recheck: Boolean = false, block: () -> String) {
        log.text = "$title…"
        Thread {
            val r = try { block() } catch (e: Throwable) { "Lỗi: ${e.message}" }
            runOnUiThread {
                log.text = "$title\n$r"
                suppress = true
                perfSwitch.isChecked = prefs.getBoolean("active", false)
                suppress = false
            }
            if (recheck) checkJoyoseStatus(false)
        }.start()
    }

    // ---------- Joyose ----------
    private fun checkJoyoseStatus(verbose: Boolean) {
        Thread {
            val r = try {
                val list = sh("pm list packages --user 0 $pkg")
                val dump = if (verbose) sh("dumpsys package $pkg | grep -i 'installed='") else ""
                Triple(list.contains("package:$pkg"), list, dump)
            } catch (e: Throwable) { null }
            runOnUiThread {
                if (r == null) {
                    joyoseText.text = "Không đọc được trạng thái"
                    joyoseText.setTextColor(SUB)
                } else {
                    joyoseText.text = if (r.first) "Đang cài" else "Đã gỡ"
                    joyoseText.setTextColor(if (r.first) OK else BAD)
                    if (verbose) log.text = "Kiểm tra Joyose\n[pm list]\n${r.second}\n\n[dumpsys]\n${r.third}"
                }
            }
        }.start()
    }

    private fun removeJoyose() = bg("Gỡ Joyose", true) { sh("pm uninstall --user 0 $pkg") }
    private fun installJoyose() = bg("Cài lại Joyose", true) { sh("pm install-existing --user 0 $pkg") }

    // ---------- Chế độ hiệu năng cao ----------
    private fun enablePerf() = bg("Bật chế độ hiệu năng cao") {
        val hz = prefs.getInt("hz", 120)
        if (!prefs.getBoolean("active", false)) {
            // Lưu giá trị gốc để khôi phục
            prefs.edit()
                .putString("o_peak", sh("settings get system peak_refresh_rate"))
                .putString("o_min", sh("settings get system min_refresh_rate"))
                .apply()
        }
        val sb = StringBuilder()
        fun step(label: String, cmd: String) {
            val out = sh(cmd)
            sb.append("• $label").append(if (out.isBlank()) ": OK" else ": $out").append("\n")
        }
        step("Tần số quét tối đa ${hz}Hz", "settings put system peak_refresh_rate $hz.0")
        step("Tần số quét tối thiểu ${hz}Hz", "settings put system min_refresh_rate $hz.0")
        step("Chế độ hiệu năng cố định", "cmd power set-fixed-performance-mode-enabled true")
        step("Báo trạng thái nhiệt = bình thường", "cmd thermalservice override-status 0")
        prefs.edit().putBoolean("active", true).apply()
        sb.append("\nĐã bật. Tắt công tắc để khôi phục như ban đầu.")
        sb.toString()
    }

    private fun restorePerf() = bg("Khôi phục bình thường") {
        val sb = StringBuilder()
        fun restoreSetting(key: String, saved: String?) {
            val cmd = if (saved.isNullOrBlank() || saved == "null") "settings delete system $key"
            else "settings put system $key $saved"
            val out = sh(cmd)
            sb.append("• $key → ${if (saved.isNullOrBlank() || saved == "null") "mặc định" else saved}")
                .append(if (out.isBlank() || out.startsWith("Deleted")) "" else " ($out)").append("\n")
        }
        restoreSetting("peak_refresh_rate", prefs.getString("o_peak", null))
        restoreSetting("min_refresh_rate", prefs.getString("o_min", null))
        sb.append("• Hiệu năng cố định: ").append(sh("cmd power set-fixed-performance-mode-enabled false").ifBlank { "OK" }).append("\n")
        sb.append("• Trạng thái nhiệt: ").append(sh("cmd thermalservice reset").ifBlank { "OK" }).append("\n")
        prefs.edit().putBoolean("active", false).apply()
        sb.append("\nĐã khôi phục.")
        sb.toString()
    }


    // ---------- Xác minh thực tế ----------
    private fun verify() = bg("Xác minh thực tế") {
        val sb = StringBuilder()
        val active = prefs.getBoolean("active", false)
        val target = prefs.getInt("hz", 120)
        sb.append(if (active) "Chế độ hiệu năng cao: ĐANG BẬT\n\n" else "Chế độ hiệu năng cao: đang tắt (chỉ hiện số liệu hiện tại)\n\n")

        // 1. Tần số quét
        val peak = sh("settings get system peak_refresh_rate")
        val min = sh("settings get system min_refresh_rate")
        val disp = sh("dumpsys display | grep -E 'mActiveModeId|DisplayModeRecord'")
        val id = Regex("mActiveModeId=(\\d+)").find(disp)?.groupValues?.get(1)
        val fps = id?.let { Regex("id=$it,[^}]*?fps=([0-9.]+)").find(disp)?.groupValues?.get(1)?.toFloatOrNull() }
        sb.append("1) Tần số quét\n")
        sb.append("   Cài đặt: peak=$peak, min=$min\n")
        if (fps != null) {
            sb.append("   Màn hình thực tế: ${fps}Hz\n")
            if (active) sb.append(
                if (fps >= target - 1f) "   ✅ HOẠT ĐỘNG: màn hình đang chạy đúng ${target}Hz\n"
                else "   ❌ KHÔNG HOẠT ĐỘNG: màn hình ở ${fps}Hz, chưa đạt ${target}Hz (ROM bỏ qua cài đặt)\n"
            )
        } else {
            sb.append("   ⚠ Không đọc được tần số thực tế từ máy này\n")
            sb.append("   ${disp.take(300)}\n")
        }

        // 2. Chế độ hiệu năng cố định
        val sup = sh("cmd power get-fixed-performance-mode-supported")
        sb.append("\n2) Hiệu năng cố định\n")
        sb.append(when {
            sup.contains("true", true) -> "   ✅ Máy có hỗ trợ tính năng này\n"
            sup.contains("false", true) -> "   ❌ Máy KHÔNG hỗ trợ → lệnh bật không có tác dụng\n"
            else -> "   ⚠ Không xác định được ($sup)\n"
        })

        // 3. Trạng thái nhiệt
        val th = sh("dumpsys thermalservice | grep -E 'IsStatusOverride|Thermal Status'")
        sb.append("\n3) Trạng thái nhiệt (chỉ là số báo cho ứng dụng)\n")
        sb.append(if (th.isBlank()) "   ⚠ Không đọc được\n" else th.lines().joinToString("\n") { "   ${it.trim()}" } + "\n")
        sb.append("   ℹ Lệnh này KHÔNG tắt giảm xung phần cứng\n")

        // 4. Nhiệt độ pin
        val bt = Regex("temperature: (\\d+)").find(sh("dumpsys battery"))?.groupValues?.get(1)?.toIntOrNull()
        sb.append("\n4) Nhiệt độ pin: ${if (bt != null) "${bt / 10.0}°C" else "không đọc được"}\n")

        // 5. Joyose
        val ps = sh("ps -A | grep -i joyose")
        sb.append("\n5) Tiến trình Joyose: ")
        sb.append(if (ps.isBlank()) "✅ không chạy" else "đang chạy")
        sb.toString()
    }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(color)
    }

    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(parent: LinearLayout) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(CARD, 24)
        setPadding(dp(20), dp(20), dp(20), dp(20))
        parent.addView(this, lp(-1, -2, b = 14))
    }

    private fun btn(label: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        stateListAnimator = null
        setTextColor(if (filled) Color.WHITE else TEXT)
        background = round(if (filled) ACCENT else CHIP, 16)
        setOnClickListener { onClick() }
        gated.add(this)
    }

    private fun updateChips() {
        val sel = prefs.getInt("hz", 120)
        chips.forEachIndexed { i, c ->
            val on = hzList[i] == sel
            c.background = round(if (on) ACCENT else CHIP, 14)
            c.setTextColor(if (on) Color.WHITE else SUB)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(56), dp(20), dp(32))
        }
        root.addView(tv("Joyose Tool", 30f, TEXT, true))
        root.addView(tv("Quản lý Joyose và hiệu năng qua Shizuku", 14f, SUB), lp(-2, -2, t = 4, b = 22))

        // Thẻ Shizuku
        val c1 = card(root)
        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        dot = View(this)
        row1.addView(dot, lp(dp(10), dp(10), r = 12))
        shizukuText = tv("", 15f, TEXT, true)
        row1.addView(shizukuText)
        c1.addView(row1)

        // Thẻ Joyose
        val c2 = card(root)
        c2.addView(tv("Joyose", 18f, TEXT, true))
        c2.addView(tv(pkg, 12f, SUB), lp(-2, -2, b = 14))
        val st = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        st.addView(tv("Trạng thái:  ", 15f, SUB))
        joyoseText = tv("—", 15f, SUB, true)
        st.addView(joyoseText)
        st.setOnClickListener { checkJoyoseStatus(true) }
        c2.addView(st, lp(-1, -2, b = 4))
        c2.addView(tv("Chạm vào dòng trạng thái để kiểm tra lại", 11f, SUB), lp(-2, -2, b = 16))
        val row2 = LinearLayout(this)
        row2.addView(btn("Gỡ Joyose", true) { removeJoyose() }, lp(0, dp(52), r = 6).apply { weight = 1f })
        row2.addView(btn("Cài lại", false) { installJoyose() }, lp(0, dp(52), l = 6).apply { weight = 1f })
        c2.addView(row2)

        // Thẻ hiệu năng cao
        val c3 = card(root)
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(tv("Chế độ hiệu năng cao", 18f, TEXT, true))
        left.addView(tv("Tắt công tắc là khôi phục lại như cũ", 12f, SUB), lp(-2, -2, t = 2))
        head.addView(left, lp(0, -2).apply { weight = 1f })
        perfSwitch = Switch(this).apply {
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                if (on) enablePerf() else restorePerf()
            }
        }
        gated.add(perfSwitch)
        head.addView(perfSwitch)
        c3.addView(head)
        c3.addView(tv("Tần số quét", 13f, SUB), lp(-2, -2, t = 18, b = 8))
        val chipRow = LinearLayout(this)
        hzList.forEach { hz ->
            val c = tv("${hz}Hz", 15f, SUB, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                setOnClickListener {
                    prefs.edit().putInt("hz", hz).apply()
                    updateChips()
                    if (prefs.getBoolean("active", false)) enablePerf()
                }
            }
            chips.add(c); gated.add(c)
            chipRow.addView(c, lp(-2, -2, r = 8))
        }
        c3.addView(chipRow)
        c3.addView(btn("Xác minh thực tế", false) { verify() }, lp(-1, dp(48), t = 16))
        c3.addView(
            tv("Lưu ý: đây là tối ưu mức phần mềm (khóa tần số quét, chế độ hiệu năng cố định). " +
                "Không phải ép xung phần cứng — việc đó cần root. Bảo vệ nhiệt của phần cứng vẫn hoạt động.", 11f, SUB),
            lp(-2, -2, t = 16)
        )

        // Thẻ log
        val c4 = card(root)
        c4.addView(tv("Kết quả", 13f, SUB), lp(-2, -2, b = 8))
        log = tv("Chưa có thao tác nào", 13f, TEXT).apply { typeface = Typeface.MONOSPACE }
        c4.addView(log)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })
    }
}
