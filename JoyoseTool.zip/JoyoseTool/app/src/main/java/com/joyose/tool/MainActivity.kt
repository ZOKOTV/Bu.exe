package com.joyose.tool

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val pkg = "com.xiaomi.joyose"
    private val hzList = listOf(90, 120, 144)

    private val BG = Color.parseColor("#080A12")
    private val TEXT = Color.parseColor("#F2F4FA")
    private val SUB = Color.parseColor("#A9B1C6")
    private val ACCENT = Color.parseColor("#6C8CFF")
    private val ACCENT_LIGHT = Color.parseColor("#9DB2FF")
    private val OK = Color.parseColor("#3DDC97")
    private val BAD = Color.parseColor("#FF6B6B")

    private lateinit var prefs: SharedPreferences
    private lateinit var dot: View
    private lateinit var shizukuText: TextView
    private lateinit var joyoseText: TextView
    private lateinit var perfSwitch: Switch
    private lateinit var speedSwitch: Switch
    private lateinit var flagSwitch: Switch
    private lateinit var deviceName: TextView
    private lateinit var deviceInfo: TextView
    private lateinit var tempSwitch: Switch
    private lateinit var fpsSwitch: Switch
    private val fpsProp = "persist.graphics.game_default_frame_rate.enabled"
    private val games = listOf("com.dts.freefireth" to "Free Fire", "com.dts.freefiremax" to "Free Fire MAX")
    private val driverState = mutableMapOf<String, Boolean>()
    private val installedState = mutableMapOf<String, Boolean>()
    private val driverStatus = mutableMapOf<String, TextView>()
    private val driverChips = mutableMapOf<String, List<TextView>>()
    private val speedChips = mutableListOf<TextView>()
    private val animKeys = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
    private val scaleList = listOf("0" to "Tắt", "0.25" to "0.25x", "0.5" to "0.5x")
    private lateinit var log: TextView
    private val gated = mutableListOf<View>()
    private val chips = mutableListOf<TextView>()
    private var suppress = false

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { connect() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh(true) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("joyose_tool", MODE_PRIVATE)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        if (prefs.getBoolean("temp", false)) startTemp()
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    override fun onResume() {
        super.onResume()
        connect()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }

    // ---------- Shizuku ----------
    private fun connect() {
        if (Shizuku.pingBinder() && !hasPerm() && !Shizuku.shouldShowRequestPermissionRationale()) {
            Shizuku.requestPermission(100)
        }
        refresh(true)
    }

    private fun hasPerm() = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun refresh(checkJoyose: Boolean = false) {
        val running = Shizuku.pingBinder()
        val ok = running && hasPerm()
        dot.background = oval(if (ok) OK else BAD)
        shizukuText.text = when {
            !running -> "Shizuku chưa chạy — hãy mở Shizuku và khởi động"
            !hasPerm() -> "Đang chờ cấp quyền Shizuku…"
            else -> "Shizuku đã kết nối"
        }
        gated.forEach { it.isEnabled = ok; it.alpha = if (ok) 1f else 0.4f }
        suppress = true
        perfSwitch.isChecked = prefs.getBoolean("active", false); speedSwitch.isChecked = prefs.getBoolean("speed", false); flagSwitch.isChecked = prefs.getBoolean("speedflag", false); fpsSwitch.isChecked = prefs.getBoolean("gamefps", false)
        suppress = false
        updateChips()
        if (ok && checkJoyose) { checkJoyoseStatus(false); syncFlag(); syncFps(); syncDrivers() }
    }

    private fun sh(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }

    private fun bg(title: String, recheck: Boolean = false, block: () -> String) {
        log.text = "$title…"
        Thread {
            val r = try { block() } catch (e: Throwable) { "Lỗi: ${e.message}" }
            runOnUiThread {
                log.text = "$title\n$r"
                if (r.contains("❌") || r.startsWith("Lỗi")) wiggle(log.parent as View)
                suppress = true
                perfSwitch.isChecked = prefs.getBoolean("active", false); speedSwitch.isChecked = prefs.getBoolean("speed", false); flagSwitch.isChecked = prefs.getBoolean("speedflag", false); fpsSwitch.isChecked = prefs.getBoolean("gamefps", false)
                suppress = false
            }
            if (recheck) checkJoyoseStatus(false)
        }.start()
    }

    // ---------- Gói hệ thống ----------
    private fun checkPkgStatus(p: String, view: TextView, verbose: Boolean) {
        Thread {
            val r = try {
                val list = sh("pm list packages --user 0 $p")
                val dump = if (verbose) sh("dumpsys package $p | grep -i 'installed='") else ""
                Triple(list.contains("package:$p"), list, dump)
            } catch (e: Throwable) { null }
            runOnUiThread {
                if (r == null) {
                    view.text = "Không đọc được trạng thái"
                    view.setTextColor(SUB)
                } else {
                    view.text = if (r.first) "Đang cài" else "Đã gỡ"
                    view.setTextColor(if (r.first) OK else BAD)
                    if (verbose) log.text = "Kiểm tra $p\n[pm list]\n${r.second}\n\n[dumpsys]\n${r.third}"
                }
            }
        }.start()
    }

    private fun checkJoyoseStatus(verbose: Boolean) = checkPkgStatus(pkg, joyoseText, verbose)

    private fun removeJoyose() = bg("Gỡ Joyose", true) { sh("pm uninstall --user 0 $pkg") }
    private fun installJoyose() = bg("Cài lại Joyose", true) { sh("pm install-existing --user 0 $pkg") }


    // ---------- Chế độ hiệu năng cao ----------
    private fun enablePerf() = bg("Bật khóa tần số quét") {
        val hz = prefs.getInt("hz", 120)
        if (!prefs.getBoolean("active", false)) {
            // Lưu giá trị gốc để khôi phục
            prefs.edit()
                .putString("o_peak", sh("settings get system peak_refresh_rate"))
                .putString("o_min", sh("settings get system min_refresh_rate"))
                .apply()
        }
        val sb = StringBuilder()
        fun step(label: String, cmd: String) {
            val out = sh(cmd)
            sb.append("• $label").append(if (out.isBlank()) ": OK" else ": $out").append("\n")
        }
        step("Tần số quét tối đa ${hz}Hz", "settings put system peak_refresh_rate $hz.0")
        step("Tần số quét tối thiểu ${hz}Hz", "settings put system min_refresh_rate $hz.0")
        prefs.edit().putBoolean("active", true).apply()
        sb.append("\nĐã bật. Tắt công tắc để khôi phục như ban đầu.")
        sb.toString()
    }

    private fun restorePerf() = bg("Khôi phục bình thường") {
        val sb = StringBuilder()
        fun restoreSetting(key: String, saved: String?) {
            val cmd = if (saved.isNullOrBlank() || saved == "null") "settings delete system $key"
            else "settings put system $key $saved"
            val out = sh(cmd)
            sb.append("• $key → ${if (saved.isNullOrBlank() || saved == "null") "mặc định" else saved}")
                .append(if (out.isBlank() || out.startsWith("Deleted")) "" else " ($out)").append("\n")
        }
        restoreSetting("peak_refresh_rate", prefs.getString("o_peak", null))
        restoreSetting("min_refresh_rate", prefs.getString("o_min", null))
        sh("cmd thermalservice reset") // dọn trạng thái nhiệt cũ nếu còn
        prefs.edit().putBoolean("active", false).apply()
        sb.append("\nĐã khôi phục.")
        sb.toString()
    }


    // ---------- Speed mode (như SetEdit) ----------
    private fun enableSpeed() = bg("Bật tăng tốc hoạt ảnh") {
        val sc = prefs.getString("scale", "0.5") ?: "0.5"
        if (!prefs.getBoolean("speed", false)) {
            val e = prefs.edit()
            animKeys.forEach { e.putString("o_$it", sh("settings get global $it")) }
            e.apply()
        }
        val sb = StringBuilder()
        animKeys.forEach { k ->
            val out = sh("settings put global $k $sc")
            val now = sh("settings get global $k")
            sb.append("• $k = $now").append(if (out.isBlank()) "" else " ($out)").append("\n")
        }
        prefs.edit().putBoolean("speed", true).apply()
        sb.append("\nĐã bật. Tắt công tắc để khôi phục như ban đầu.")
        sb.toString()
    }

    private fun restoreSpeed() = bg("Khôi phục hoạt ảnh") {
        val sb = StringBuilder()
        animKeys.forEach { k ->
            val saved = prefs.getString("o_$k", null)
            val unset = saved.isNullOrBlank() || saved == "null"
            sh(if (unset) "settings delete global $k" else "settings put global $k $saved")
            sb.append("• $k → ${if (unset) "mặc định (1.0)" else saved}\n")
        }
        prefs.edit().putBoolean("speed", false).apply()
        sb.append("\nĐã khôi phục.")
        sb.toString()
    }

    // ---------- speed_mode_enable (Secure) ----------
    private fun setSpeedFlag(on: Boolean) = bg(if (on) "Bật chế độ siêu cấp" else "Tắt chế độ siêu cấp") {
        val v = if (on) "1" else "0"
        val o1 = sh("settings put system speed_mode $v")
        val o2 = sh("settings put secure speed_mode_enable $v")
        val a = sh("settings get system speed_mode")
        val b = sh("settings get secure speed_mode_enable")
        prefs.edit().putBoolean("speedflag", a == "1" && b == "1").apply()
        "• system speed_mode = $a" + (if (o1.isBlank()) "" else " ($o1)") + "\n" +
            "• secure speed_mode_enable = $b" + (if (o2.isBlank()) "" else " ($o2)") + "\n" +
            (if (a == v && b == v) "✅ Đã ghi đúng. Kiểm tra: Tùy chọn nhà phát triển → Chế độ siêu cấp"
            else "❌ Có giá trị không đổi — hệ thống có thể chặn")
    }

    private fun syncFlag() {
        Thread {
            val a = try { sh("settings get system speed_mode") } catch (e: Throwable) { "" }
            val b = try { sh("settings get secure speed_mode_enable") } catch (e: Throwable) { "" }
            if (a.isNotEmpty() || b.isNotEmpty()) {
                val on = a == "1" && b == "1"
                prefs.edit().putBoolean("speedflag", on).apply()
                runOnUiThread {
                    suppress = true; flagSwitch.isChecked = on; suppress = false
                }
            }
        }.start()
    }

    // ---------- Thông báo nhiệt độ ----------
    private fun startTemp() {
        val i = Intent(this, TempService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun stopTemp() { stopService(Intent(this, TempService::class.java)) }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (granted) {
                prefs.edit().putBoolean("temp", true).apply(); startTemp()
            } else {
                suppress = true; tempSwitch.isChecked = false; suppress = false
                log.text = "Cần cấp quyền Thông báo cho tđ.exe để hiện nhiệt độ"
            }
        }
    }

    // ---------- Thông tin thiết bị ----------
    private fun prop(n: String): String = try {
        Runtime.getRuntime().exec(arrayOf("getprop", n)).inputStream.bufferedReader().readText().trim()
    } catch (e: Throwable) { "" }

    private fun loadDevice() {
        Thread {
            val market = listOf("ro.product.marketname", "ro.product.vendor.marketname")
                .map { prop(it) }.firstOrNull { it.isNotBlank() }
            val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
            val name = market ?: "$brand ${Build.MODEL}"
            val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() &&
                !Build.SOC_MODEL.equals("unknown", true)) Build.SOC_MODEL else null
            val ramKb = try {
                java.io.File("/proc/meminfo").readLines().firstOrNull { it.startsWith("MemTotal:") }
                    ?.replace(Regex("[^0-9]"), "")?.toLongOrNull()
            } catch (e: Throwable) { null }
            val ram = ramKb?.let { String.format(java.util.Locale.US, "RAM %.1f GB", it / 1048576.0) }
            val info = listOfNotNull(Build.MODEL, "Android ${Build.VERSION.RELEASE}", soc, ram).joinToString("  •  ")
            runOnUiThread { deviceName.text = name; deviceInfo.text = info }
        }.start()
    }

    // ---------- Tăng tốc máy (có số liệu trước/sau) ----------
    private fun memKb(key: String): Long =
        sh("grep $key: /proc/meminfo").replace(Regex("[^0-9]"), "").toLongOrNull() ?: 0L

    private fun freeStorageKb(): Long =
        sh("df -k /data | tail -1").trim().split(Regex("\\s+")).getOrNull(3)?.toLongOrNull() ?: 0L

    private fun freeRam() = bg("Giải phóng RAM") {
        val before = memKb("MemAvailable")
        sh("am kill-all")
        Thread.sleep(1500)
        val after = memKb("MemAvailable")
        "RAM trống trước: ${before / 1024} MB\n" +
            "RAM trống sau:   ${after / 1024} MB\n" +
            "Chênh lệch:      ${(after - before) / 1024} MB\n\n" +
            "Ứng dụng nền bị đóng sẽ tự mở lại khi bạn dùng, nên lợi ích chỉ kéo dài ngắn."
    }

    private fun trimCaches() = bg("Dọn bộ nhớ đệm") {
        val before = freeStorageKb()
        val out = sh("pm trim-caches 999G")
        val after = freeStorageKb()
        "Bộ nhớ trống trước: ${before / 1024} MB\n" +
            "Bộ nhớ trống sau:   ${after / 1024} MB\n" +
            "Đã giải phóng:      ${(after - before) / 1024} MB" +
            (if (out.isBlank()) "" else "\n$out")
    }

    private fun compileApps() = bg("Tối ưu ứng dụng (mất vài phút, đừng thoát app)") {
        val out = sh("cmd package compile -m speed-profile -a")
        "Hoàn tất.\n" + out.lines().takeLast(6).joinToString("\n")
    }

    // ---------- Tắt FPS mặc định của game ----------
    // Công tắc trong Tùy chọn nhà phát triển đổi thuộc tính này giữa "true" và "false"
    // (false = đã tắt giới hạn 60Hz mặc định)
    private fun setGameFps(disable: Boolean) = bg(if (disable) "Tắt giới hạn FPS mặc định" else "Bật lại giới hạn FPS mặc định") {
        val v = if (disable) "false" else "true"
        val out = sh("setprop $fpsProp $v")
        val now = sh("getprop $fpsProp")
        prefs.edit().putBoolean("gamefps", now == "false").apply()
        "• $fpsProp = ${now.ifBlank { "(trống)" }}" + (if (out.isBlank()) "" else " ($out)") + "\n" +
            (if (now == v) "✅ Đã ghi đúng giá trị $v"
            else "❌ Máy chặn lệnh này. Bấm \"Mở Tùy chọn nhà phát triển\" để bật tay, hoặc dùng mục Dò khóa để tôi tìm cách khác.")
    }

    private fun syncFps() {
        Thread {
            val v = try { sh("getprop $fpsProp") } catch (e: Throwable) { null }
            if (v != null) {
                prefs.edit().putBoolean("gamefps", v == "false").apply()
                runOnUiThread { suppress = true; fpsSwitch.isChecked = v == "false"; suppress = false }
            }
        }.start()
    }

    // ---------- Trình điều khiển đồ họa theo từng game ----------
    // Android 12+ dùng khóa updatable_driver_*, bản cũ dùng game_driver_* → ghi cả hai cho chắc.
    private val outKeys = listOf("updatable_driver_production_opt_out_apps", "game_driver_opt_out_apps")
    private val inKeys = listOf(
        "updatable_driver_production_opt_in_apps", "updatable_driver_prerelease_opt_in_apps",
        "game_driver_opt_in_apps", "game_driver_prerelease_opt_in_apps"
    )

    private fun getList(key: String): MutableList<String> {
        val v = sh("settings get global $key").trim()
        return if (v.isBlank() || v == "null") mutableListOf()
        else v.split(",", ";").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
    }

    private fun putList(key: String, list: List<String>) {
        if (list.isEmpty()) sh("settings delete global $key")
        else sh("settings put global $key ${list.joinToString(",")}")
    }

    private fun setDriver(pk: String, name: String, system: Boolean) =
        bg("$name → " + (if (system) "Hệ thống" else "Mặc định")) {
            val sb = StringBuilder()
            outKeys.forEach { k ->
                val l = getList(k)
                val had = l.contains(pk)
                l.remove(pk)
                if (system) l.add(pk)
                if (had != system || system) putList(k, l)
            }
            inKeys.forEach { k ->
                val l = getList(k)
                if (l.remove(pk)) putList(k, l)
            }
            var ok = true
            outKeys.forEach { k ->
                val now = getList(k)
                if (now.contains(pk) != system) ok = false
                sb.append("• $k = ${now.joinToString(",").ifBlank { "(trống)" }}\n")
            }
            runOnUiThread { driverState[pk] = system && ok; updateDriverUi() }
            sb.append(if (ok) "\n✅ Đã ghi. Thoát hẳn game rồi mở lại. Nếu mục Cài đặt vẫn báo Mặc định, hãy dùng Dò khóa bên dưới."
            else "\n❌ Giá trị không đổi — hệ thống có thể chặn")
            sb.toString()
        }

    private fun syncDrivers() {
        Thread {
            try {
                val pk = sh("pm list packages --user 0 com.dts.freefire")
                val sys = outKeys.flatMap { getList(it) }.toSet()
                runOnUiThread {
                    games.forEach { (p, _) ->
                        driverState[p] = sys.contains(p)
                        installedState[p] = pk.contains("package:$p")
                    }
                    updateDriverUi()
                }
            } catch (e: Throwable) { }
        }.start()
    }

    // ---------- Dò khóa: so sánh Settings trước/sau khi bạn tự đổi bằng tay ----------
    private var snapA: Map<String, String>? = null

    private fun snapshot(): Map<String, String> {
        val m = linkedMapOf<String, String>()
        listOf("global", "secure", "system").forEach { t ->
            sh("settings list $t").lines().forEach { ln ->
                val i = ln.indexOf('=')
                if (i > 0) m["$t:${ln.substring(0, i)}"] = ln.substring(i + 1)
            }
        }
        val keep = Regex("graphics|game|frame|driver|angle", RegexOption.IGNORE_CASE)
        sh("getprop").lines().forEach { ln ->
            val r = Regex("^\\[(.*?)\\]: \\[(.*)\\]$").find(ln.trim())
            if (r != null && keep.containsMatchIn(r.groupValues[1])) m["prop:" + r.groupValues[1]] = r.groupValues[2]
        }
        return m
    }

    private fun takeSnap() = bg("Chụp trạng thái") {
        val m = snapshot()
        snapA = m
        "Đã chụp ${m.size} mục.\nBây giờ vào Cài đặt, TỰ bật công tắc hoặc chọn trình điều khiển, " +
            "rồi quay lại bấm \"2. So sánh\"."
    }

    private fun compareSnap() = bg("So sánh") {
        val a = snapA
        if (a == null) "Chưa chụp ở bước 1." else {
            val b = snapshot()
            val noise = Regex("time|last|elapsed|count|uptime|date|seq|bytes|stamp", RegexOption.IGNORE_CASE)
            val lines = mutableListOf<String>()
            (a.keys + b.keys).toSortedSet().forEach { k ->
                val x = a[k]; val y = b[k]
                if (x != y && !noise.containsMatchIn(k)) {
                    lines.add("$k: ${(x ?: "(không có)").take(120)} → ${(y ?: "(đã xóa)").take(120)}")
                }
            }
            if (lines.isEmpty()) "Không thấy khóa nào đổi."
            else lines.take(40).joinToString("\n") + (if (lines.size > 40) "\n… (+${lines.size - 40} dòng)" else "")
        }
    }

    private fun updateDriverUi() {
        games.forEach { (p, _) ->
            val sys = driverState[p] == true
            val inst = installedState[p] == true
            driverStatus[p]?.text = (if (inst) "Đã cài" else "Chưa cài trên máy") +
                "  •  đang dùng: " + (if (sys) "Hệ thống" else "Mặc định")
            driverChips[p]?.forEachIndexed { i, c -> chipStyle(c, (i == 1) == sys) }
        }
    }

    // ---------- Xác minh thực tế ----------
    private fun verify() = bg("Xác minh thực tế") {
        val sb = StringBuilder()
        val active = prefs.getBoolean("active", false)
        val target = prefs.getInt("hz", 120)
        sb.append(if (active) "Khóa tần số quét: ĐANG BẬT\n\n" else "Khóa tần số quét: đang tắt (chỉ hiện số liệu hiện tại)\n\n")

        // 1. Tần số quét
        val peak = sh("settings get system peak_refresh_rate")
        val min = sh("settings get system min_refresh_rate")
        val disp = sh("dumpsys display | grep -E 'mActiveModeId|DisplayModeRecord'")
        val id = Regex("mActiveModeId=(\\d+)").find(disp)?.groupValues?.get(1)
        val fps = id?.let { Regex("id=$it,[^}]*?fps=([0-9.]+)").find(disp)?.groupValues?.get(1)?.toFloatOrNull() }
        sb.append("1) Tần số quét\n")
        sb.append("   Cài đặt: peak=$peak, min=$min\n")
        if (fps != null) {
            sb.append("   Màn hình thực tế: ${fps}Hz\n")
            if (active) sb.append(
                if (fps >= target - 1f) "   ✅ HOẠT ĐỘNG: màn hình đang chạy đúng ${target}Hz\n"
                else "   ❌ KHÔNG HOẠT ĐỘNG: màn hình ở ${fps}Hz, chưa đạt ${target}Hz (ROM bỏ qua cài đặt)\n"
            )
        } else {
            sb.append("   ⚠ Không đọc được tần số thực tế từ máy này\n")
            sb.append("   ${disp.take(300)}\n")
        }

        // 2. Nhiệt độ pin
        val bt = Regex("temperature: (\\d+)").find(sh("dumpsys battery"))?.groupValues?.get(1)?.toIntOrNull()
        sb.append("\n2) Nhiệt độ pin: ${if (bt != null) "${bt / 10.0}°C" else "không đọc được"}\n")

        // 3. Joyose (đếm tiến trình khớp tên chính xác; ký tự [e] để lệnh grep không tự khớp chính nó)
        val n = sh("ps -A -o NAME | grep -c 'com.xiaomi.joyos[e]'").trim().toIntOrNull()
        sb.append("\n3) Tiến trình Joyose: ")
        sb.append(when {
            n == null -> "⚠ không đọc được"
            n == 0 -> "✅ không chạy"
            else -> "đang chạy ($n tiến trình)"
        })
        sb.append("\n")

        // 4. Hoạt ảnh
        val av = animKeys.map { sh("settings get global $it") }
        sb.append("\n4) Tăng tốc hoạt ảnh\n   ${av.joinToString(" / ")}\n")
        if (prefs.getBoolean("speed", false)) {
            val sc = (prefs.getString("scale", "0.5") ?: "0.5").toFloat()
            val ok = av.all { it.toFloatOrNull() == sc }
            sb.append(if (ok) "   ✅ HOẠT ĐỘNG: cả 3 giá trị đã đổi\n" else "   ❌ Có giá trị chưa được đổi\n")
        }

        // 5. Chế độ siêu cấp
        sb.append("\n5) Chế độ siêu cấp\n   system speed_mode = ${sh("settings get system speed_mode")}\n   secure speed_mode_enable = ${sh("settings get secure speed_mode_enable")}\n")

        // 6. FPS mặc định của game
        sb.append("\n6) Giới hạn FPS mặc định của game\n   $fpsProp = ${sh("getprop $fpsProp").ifBlank { "(trống)" }}\n")

        // 7. Trình điều khiển đồ họa
        sb.append("\n7) Trình điều khiển đồ họa (danh sách dùng Hệ thống)\n")
        outKeys.forEach { k -> sb.append("   $k = ${getList(k).joinToString(",").ifBlank { "(trống)" }}\n") }
        sb.toString()
    }

    // ---------- UI: kính + 3D ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(color)
    }

    /** Nền kính: lớp mờ trắng trong suốt + viền sáng mảnh. */
    private fun glass(radius: Int): LayerDrawable {
        val r = dp(radius).toFloat()
        val fill = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x2EFFFFFF, 0x0DFFFFFF)
        ).apply { cornerRadius = r }
        val edge = GradientDrawable().apply {
            cornerRadius = r; setColor(Color.TRANSPARENT); setStroke(dp(1), 0x47FFFFFF)
        }
        return LayerDrawable(arrayOf(fill, edge))
    }

    /** Nút nổi 3D: đáy tối + mặt gradient + vệt bóng phía trên. */
    private fun face3d(top: Int, bottom: Int, depthColor: Int, radius: Int, depth: Int): LayerDrawable {
        val r = dp(radius).toFloat()
        val base = GradientDrawable().apply { setColor(depthColor); cornerRadius = r }
        val face = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom))
            .apply { cornerRadius = r }
        val shine = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x66FFFFFF, 0x00FFFFFF)
        ).apply { cornerRadius = r }
        return LayerDrawable(arrayOf(base, face, shine)).apply {
            setLayerInset(1, 0, 0, 0, dp(depth))
            setLayerInset(2, dp(3), dp(2), dp(3), dp(depth) + dp(26))
        }
    }

    /** Lắc nhẹ (wiggle) qua lại như kiểu rung lắc biểu tượng. */
    private fun wiggle(v: View) {
        ObjectAnimator.ofFloat(v, View.ROTATION, 0f, -4f, 4f, -3f, 3f, -1.5f, 1.5f, 0f).apply {
            duration = 450
            start()
        }
    }

    private fun pressFx(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.96f).scaleY(0.96f).translationY(dp(2).toFloat())
                        .setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).translationY(0f)
                        .setDuration(260).setInterpolator(OvershootInterpolator(2.2f)).start()
                    if (e.action == MotionEvent.ACTION_UP) wiggle(view)
                }
            }
            false
        }
    }

    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(parent: LinearLayout) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = glass(26)
        setPadding(dp(20), dp(20), dp(20), dp(20))
        parent.addView(this, lp(-1, -2, b = 14))
    }

    private fun btn(label: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        stateListAnimator = null
        setTextColor(Color.WHITE)
        setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), 0x66000000)
        background = if (primary)
            face3d(0xFF9DB2FF.toInt(), 0xFF5A6CFF.toInt(), 0xFF2B37A0.toInt(), 18, 5)
        else
            face3d(0x4DFFFFFF, 0x14FFFFFF, 0x40000000, 18, 5)
        setPadding(0, 0, 0, dp(5))
        pressFx(this)
        setOnClickListener { onClick() }
        gated.add(this)
    }

    private fun chipStyle(c: TextView, on: Boolean) {
        c.background = if (on)
            face3d(0xFF9DB2FF.toInt(), 0xFF5A6CFF.toInt(), 0xFF2B37A0.toInt(), 14, 3)
        else glass(14)
        c.setTextColor(if (on) Color.WHITE else SUB)
    }

    private fun tintSwitch(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(ACCENT_LIGHT, 0xFFC4CADA.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x886C8CFF.toInt(), 0x44FFFFFF))
    }

    private fun updateSpeedChips() {
        val sel = prefs.getString("scale", "0.5")
        speedChips.forEachIndexed { i, c ->
            val on = scaleList[i].first == sel
            c.background = if (on)
                face3d(0xFF9DB2FF.toInt(), 0xFF5A6CFF.toInt(), 0xFF2B37A0.toInt(), 14, 3)
            else glass(14)
            c.setTextColor(if (on) Color.WHITE else SUB)
        }
    }

    private fun updateChips() {
        val sel = prefs.getInt("hz", 120)
        chips.forEachIndexed { i, c ->
            val on = hzList[i] == sel
            c.background = if (on)
                face3d(0xFF9DB2FF.toInt(), 0xFF5A6CFF.toInt(), 0xFF2B37A0.toInt(), 14, 3)
            else glass(14)
            c.setTextColor(if (on) Color.WHITE else SUB)
        }
        updateSpeedChips()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(52), dp(20), dp(32))
        }

        // Tiêu đề: chữ gradient + bóng nổi
        val title = tv("tđ.exe", 36f, Color.WHITE, true).apply {
            setShadowLayer(dp(10).toFloat(), 0f, dp(4).toFloat(), 0x886C8CFF.toInt())
            post {
                val w = paint.measureText(text.toString())
                paint.shader = LinearGradient(
                    0f, 0f, w, 0f,
                    intArrayOf(Color.WHITE, 0xFFB7C6FF.toInt(), 0xFFD7A8FF.toInt()), null, Shader.TileMode.CLAMP
                )
                invalidate()
            }
        }
        root.addView(title)
        title.setOnClickListener { wiggle(it) }
        root.addView(tv("Joyose  •  Hiệu năng  •  Shizuku", 13f, SUB), lp(-2, -2, t = 2, b = 22))

        // Thẻ thiết bị
        val c0 = card(root)
        deviceName = tv(Build.MODEL, 22f, TEXT, true)
        deviceInfo = tv("", 12f, SUB)
        c0.addView(tv("THIẾT BỊ CỦA BẠN", 11f, ACCENT_LIGHT, true), lp(-2, -2, b = 6))
        c0.addView(deviceName)
        c0.addView(deviceInfo, lp(-2, -2, t = 4))
        loadDevice()

        // Thẻ Shizuku
        val c1 = card(root)
        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        dot = View(this)
        row1.addView(dot, lp(dp(10), dp(10), r = 12))
        ObjectAnimator.ofPropertyValuesHolder(
            dot,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.5f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.5f),
            PropertyValuesHolder.ofFloat("alpha", 1f, 0.45f)
        ).apply {
            duration = 1000; repeatMode = android.animation.ValueAnimator.REVERSE
            repeatCount = android.animation.ValueAnimator.INFINITE; start()
        }
        shizukuText = tv("", 15f, TEXT, true)
        row1.addView(shizukuText)
        c1.addView(row1)

        // Thẻ Joyose
        val c2 = card(root)
        c2.addView(tv("Joyose", 18f, TEXT, true))
        c2.addView(tv(pkg, 12f, SUB), lp(-2, -2, b = 14))
        val st = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        st.addView(tv("Trạng thái:  ", 15f, SUB))
        joyoseText = tv("—", 15f, SUB, true)
        st.addView(joyoseText)
        st.setOnClickListener { checkJoyoseStatus(true) }
        c2.addView(st, lp(-1, -2, b = 4))
        c2.addView(tv("Chạm vào dòng trạng thái để kiểm tra lại", 11f, SUB), lp(-2, -2, b = 16))
        val row2 = LinearLayout(this)
        row2.addView(btn("Gỡ Joyose", true) { removeJoyose() }, lp(0, dp(58), r = 6).apply { weight = 1f })
        row2.addView(btn("Cài lại", false) { installJoyose() }, lp(0, dp(58), l = 6).apply { weight = 1f })
        c2.addView(row2)

        // Thẻ hiệu năng cao
        val c3 = card(root)
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(tv("Khóa tần số quét", 18f, TEXT, true))
        left.addView(tv("Tắt công tắc là khôi phục lại như cũ", 12f, SUB), lp(-2, -2, t = 2))
        head.addView(left, lp(0, -2).apply { weight = 1f })
        perfSwitch = Switch(this).apply {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(ACCENT_LIGHT, 0xFFC4CADA.toInt()))
            trackTintList = ColorStateList(states, intArrayOf(0x886C8CFF.toInt(), 0x44FFFFFF))
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                if (on) enablePerf() else restorePerf()
            }
        }
        gated.add(perfSwitch)
        head.addView(perfSwitch)
        c3.addView(head)
        c3.addView(tv("Tần số quét", 13f, SUB), lp(-2, -2, t = 18, b = 8))
        val chipRow = LinearLayout(this)
        hzList.forEach { hz ->
            val c = tv("${hz}Hz", 15f, SUB, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                pressFx(this)
                setOnClickListener {
                    prefs.edit().putInt("hz", hz).apply()
                    updateChips()
                    if (prefs.getBoolean("active", false)) enablePerf()
                }
            }
            chips.add(c); gated.add(c)
            chipRow.addView(c, lp(-2, -2, r = 8))
        }
        c3.addView(chipRow)
        c3.addView(btn("Xác minh thực tế", false) { verify() }, lp(-1, dp(58), t = 16))
        c3.addView(
            tv("Khóa tần số quét ở mức bạn chọn. " +
                "Game vẫn quyết định số khung hình thực tế, nên màn hình chỉ lên 120Hz khi game xuất đủ 120 FPS.", 11f, SUB),
            lp(-2, -2, t = 16)
        )

        // Thẻ tăng tốc máy
        val c8 = card(root)
        c8.addView(tv("Tăng tốc máy", 18f, TEXT, true))
        c8.addView(
            tv("Không tăng sức mạnh phần cứng, nhưng giải phóng tài nguyên và tối ưu ứng dụng để máy mượt hơn. " +
                "Mỗi nút hiện số liệu trước và sau để bạn tự kiểm chứng.", 12f, SUB),
            lp(-2, -2, t = 2, b = 14)
        )
        c8.addView(btn("Giải phóng RAM", true) { freeRam() }, lp(-1, dp(58)))
        c8.addView(btn("Dọn bộ nhớ đệm", false) { trimCaches() }, lp(-1, dp(58), t = 10))
        c8.addView(btn("Tối ưu ứng dụng (mở app nhanh hơn)", false) { compileApps() }, lp(-1, dp(58), t = 10))
        c8.addView(
            tv("Tối ưu ứng dụng mất vài phút và hao pin, nên cắm sạc. Tác dụng thấy rõ nhất ở tốc độ mở app.", 11f, SUB),
            lp(-2, -2, t = 14)
        )

        // Thẻ Speed mode
        val c5 = card(root)
        val head2 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left2.addView(tv("Tăng tốc hoạt ảnh", 18f, TEXT, true))
        left2.addView(tv("Rút ngắn hoạt ảnh — tắt là khôi phục", 12f, SUB), lp(-2, -2, t = 2))
        head2.addView(left2, lp(0, -2).apply { weight = 1f })
        speedSwitch = Switch(this).apply {
            tintSwitch(this)
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                if (on) enableSpeed() else restoreSpeed()
            }
        }
        gated.add(speedSwitch)
        head2.addView(speedSwitch)
        c5.addView(head2)
        c5.addView(tv("Tốc độ hoạt ảnh", 13f, SUB), lp(-2, -2, t = 18, b = 8))
        val scaleRow = LinearLayout(this)
        scaleList.forEach { (value, label) ->
            val c = tv(label, 15f, SUB, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                pressFx(this)
                setOnClickListener {
                    prefs.edit().putString("scale", value).apply()
                    updateSpeedChips()
                    if (prefs.getBoolean("speed", false)) enableSpeed()
                }
            }
            speedChips.add(c); gated.add(c)
            scaleRow.addView(c, lp(-2, -2, r = 8))
        }
        c5.addView(scaleRow)
        c5.addView(
            tv("Chỉnh 3 giá trị: window_animation_scale, transition_animation_scale, animator_duration_scale. " +
                "Chỉ làm giao diện chuyển cảnh nhanh hơn, không tăng sức mạnh xử lý.", 11f, SUB),
            lp(-2, -2, t = 16)
        )

        // Thẻ speed_mode_enable
        val c6 = card(root)
        val head3 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left3 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left3.addView(tv("Chế độ siêu cấp", 18f, TEXT, true))
        left3.addView(tv("Giống mục trong Tùy chọn nhà phát triển", 12f, SUB), lp(-2, -2, t = 2))
        head3.addView(left3, lp(0, -2).apply { weight = 1f })
        flagSwitch = Switch(this).apply {
            tintSwitch(this)
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                setSpeedFlag(on)
            }
        }
        gated.add(flagSwitch)
        head3.addView(flagSwitch)
        c6.addView(head3)
        c6.addView(
            tv("Ghi cả speed_mode (System) và speed_mode_enable (Secure): bật = 1, tắt = 0, rồi đọc lại. " +
                "Sau khi bật, vào Tùy chọn nhà phát triển để thấy công tắc Chế độ siêu cấp đổi theo.", 11f, SUB),
            lp(-2, -2, t = 14)
        )

        // Thẻ thông báo nhiệt độ
        val c7 = card(root)
        val head4 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left4 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left4.addView(tv("Thông báo nhiệt độ", 18f, TEXT, true))
        left4.addView(tv("Hiện số độ C ngay trên thanh trạng thái", 12f, SUB), lp(-2, -2, t = 2))
        head4.addView(left4, lp(0, -2).apply { weight = 1f })
        tempSwitch = Switch(this).apply {
            tintSwitch(this)
            isChecked = prefs.getBoolean("temp", false)
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                if (on) {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
                    } else {
                        prefs.edit().putBoolean("temp", true).apply(); startTemp()
                    }
                } else {
                    prefs.edit().putBoolean("temp", false).apply(); stopTemp()
                }
            }
        }
        head4.addView(tempSwitch)
        c7.addView(head4)
        c7.addView(
            tv("Đo nhiệt độ pin (không cần Shizuku). Nếu thông báo biến mất, vào Cài đặt → Ứng dụng → tđ.exe " +
                "→ Tiết kiệm pin → chọn Không hạn chế.", 11f, SUB),
            lp(-2, -2, t = 14)
        )

        // Thẻ tắt FPS mặc định của game
        val c9 = card(root)
        val head5 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left5 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left5.addView(tv("Tắt FPS mặc định của game", 18f, TEXT, true))
        left5.addView(tv("Bỏ giới hạn 60Hz cho trò chơi", 12f, SUB), lp(-2, -2, t = 2))
        head5.addView(left5, lp(0, -2).apply { weight = 1f })
        fpsSwitch = Switch(this).apply {
            tintSwitch(this)
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                setGameFps(on)
            }
        }
        gated.add(fpsSwitch)
        head5.addView(fpsSwitch)
        c9.addView(head5)
        c9.addView(
            tv("Giống mục \"Tắt tốc độ khung hình mặc định cho trò chơi\" trong Tùy chọn nhà phát triển. " +
                "Nếu máy chặn lệnh, app sẽ báo ❌ — khi đó bấm nút dưới để bật bằng tay.", 11f, SUB),
            lp(-2, -2, t = 14, b = 12)
        )
        val devBtn = btn("Mở Tùy chọn nhà phát triển", false) {
            startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        }
        gated.remove(devBtn)
        c9.addView(devBtn, lp(-1, dp(56)))

        // Thẻ trình điều khiển đồ họa
        val c10 = card(root)
        c10.addView(tv("Trình điều khiển đồ họa", 18f, TEXT, true))
        c10.addView(tv("Đặt riêng cho từng bản Free Fire", 12f, SUB), lp(-2, -2, t = 2, b = 4))
        games.forEach { (pk, name) ->
            c10.addView(tv(name, 15f, TEXT, true), lp(-2, -2, t = 14))
            val stv = tv("Đang kiểm tra…", 11f, SUB)
            driverStatus[pk] = stv
            c10.addView(stv, lp(-2, -2, t = 2, b = 8))
            val row = LinearLayout(this)
            val chipsForGame = mutableListOf<TextView>()
            listOf("Mặc định" to false, "Hệ thống" to true).forEach { (label, sys) ->
                val c = tv(label, 14f, SUB, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(18), dp(11), dp(18), dp(11))
                    pressFx(this)
                    setOnClickListener { setDriver(pk, name, sys) }
                }
                chipStyle(c, false)
                chipsForGame.add(c); gated.add(c)
                row.addView(c, lp(-2, -2, r = 8))
            }
            driverChips[pk] = chipsForGame
            c10.addView(row)
        }
        c10.addView(
            tv("Giống mục Các lựa chọn ưu tiên về trình điều khiển đồ họa. Sau khi đổi, thoát hẳn game rồi mở lại.", 11f, SUB),
            lp(-2, -2, t = 16)
        )

        // Thẻ dò khóa
        val c11 = card(root)
        c11.addView(tv("Dò khóa hệ thống", 18f, TEXT, true))
        c11.addView(
            tv("Dùng khi một mục không chạy: chụp trạng thái, tự đổi bằng tay trong Cài đặt, rồi so sánh để biết " +
                "Cài đặt thực sự thay đổi khóa nào. Gửi kết quả cho tôi để sửa app.", 12f, SUB),
            lp(-2, -2, t = 2, b = 14)
        )
        c11.addView(btn("1. Chụp trạng thái", false) { takeSnap() }, lp(-1, dp(56)))
        c11.addView(btn("2. So sánh sau khi tự đổi", true) { compareSnap() }, lp(-1, dp(56), t = 10))

        // Thẻ kết quả
        val c4 = card(root)
        c4.addView(tv("Kết quả", 13f, SUB), lp(-2, -2, b = 8))
        log = tv("Chưa có thao tác nào", 13f, TEXT).apply { typeface = Typeface.MONOSPACE }
        c4.addView(log)

        // Hiệu ứng xuất hiện lần lượt
        for (i in 0 until root.childCount) {
            val v = root.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(28).toFloat()
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(i * 70L).setDuration(520)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        }

        val frame = FrameLayout(this)
        frame.addView(OrbView(this), FrameLayout.LayoutParams(-1, -1))
        frame.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(root)
        }, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
    }
}
