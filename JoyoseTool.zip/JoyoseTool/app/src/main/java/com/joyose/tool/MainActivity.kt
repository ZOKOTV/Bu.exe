package com.joyose.tool

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val pkg = "com.xiaomi.joyose"
    private val hzList = listOf(90, 120, 144)

    private val BG = Color.parseColor("#080A12")
    private val TEXT = Color.parseColor("#F2F4FA")
    private val SUB = Color.parseColor("#A9B1C6")
    private val ACCENT = Color.parseColor("#6C8CFF")
    private val ACCENT_LIGHT = Color.parseColor("#9DB2FF")
    private val OK = Color.parseColor("#3DDC97")
    private val BAD = Color.parseColor("#FF6B6B")

    private lateinit var prefs: SharedPreferences
    private lateinit var dot: View
    private lateinit var shizukuText: TextView
    private lateinit var joyoseText: TextView
    private lateinit var pkText: TextView
    private lateinit var dpiInfo: TextView
    private lateinit var etW: android.widget.EditText
    private lateinit var etH: android.widget.EditText
    private lateinit var etD: android.widget.EditText
    private lateinit var etS: android.widget.EditText
    private lateinit var lockSwitch: Switch
    private var fieldsBusy = false
    private var physW = 0
    private var physH = 0
    private var physD = 0
    private var curW = 0
    private var curH = 0
    private var curD = 0
    private var curSw = -1          // độ rộng nhỏ nhất (dp) hệ thống đang báo, -1 nếu không đọc được
    private var lastEdit = 'S'     // ô người dùng sửa sau cùng: S = dp, D = DPI
    private val dpiHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val pkg2 = "com.miui.powerkeeper"
    private lateinit var perfSwitch: Switch
    private lateinit var speedSwitch: Switch
    private lateinit var flagSwitch: Switch
    private lateinit var deviceName: TextView
    private lateinit var deviceInfo: TextView
    private lateinit var tempSwitch: Switch
    private lateinit var fpsSwitch: Switch
    private lateinit var resultPanelRef: View
    private lateinit var hzSwitch: Switch
    private val ovPosChips = mutableListOf<TextView>()
    private val ovSizeChips = mutableListOf<TextView>()
    private var privacySwitch: Switch? = null
    private var pingStatus: TextView? = null
    private val fpsProp = "debug.graphics.game_default_frame_rate.disabled"
    private val games = listOf("com.dts.freefireth" to "Free Fire", "com.dts.freefiremax" to "Free Fire MAX")
    private val driverState = mutableMapOf<String, Boolean>()
    private val installedState = mutableMapOf<String, Boolean>()
    private val driverStatus = mutableMapOf<String, TextView>()
    private val driverChips = mutableMapOf<String, List<TextView>>()
    private val speedChips = mutableListOf<TextView>()
    private val animKeys = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
    private val scaleList = listOf("0" to "Tắt", "0.25" to "0.25x", "0.5" to "0.5x")
    private lateinit var log: TextView
    private val gated = mutableListOf<View>()
    private val chips = mutableListOf<TextView>()
    private var suppress = false

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { connect() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh(true) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("joyose_tool", MODE_PRIVATE)
        // Lớp phủ tốc độ làm mới mất sau khi khởi động lại máy → đặt lại công tắc theo số lần khởi động
        val bc = try {
            android.provider.Settings.Global.getInt(contentResolver, android.provider.Settings.Global.BOOT_COUNT, -1)
        } catch (e: Throwable) { -1 }
        if (prefs.getInt("bc", -2) != bc) prefs.edit().putInt("bc", bc).putBoolean("showhz", false).apply()
        if (!OverlayService.running) prefs.edit().putBoolean("showhz", false).apply()
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        if (prefs.getBoolean("temp", false)) startTemp()
        if (BuildConfig.ANALYTICS_URL.isNotBlank()) {
            if (!prefs.contains("analytics")) askConsent() else pingAnalytics()
        }
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (physW != 0) updateDpiUi()
    }

    override fun onResume() {
        super.onResume()
        connect()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }

    // ---------- Shizuku ----------
    private fun connect() {
        if (Shizuku.pingBinder() && !hasPerm() && !Shizuku.shouldShowRequestPermissionRationale()) {
            Shizuku.requestPermission(100)
        }
        refresh(true)
    }

    private fun hasPerm() = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun refresh(checkJoyose: Boolean = false) {
        val running = Shizuku.pingBinder()
        val ok = running && hasPerm()
        dot.background = oval(if (ok) OK else BAD)
        shizukuText.text = when {
            !running -> "Shizuku chưa chạy"
            !hasPerm() -> "Chờ cấp quyền Shizuku…"
            else -> "Shizuku đã kết nối"
        }
        gated.forEach { it.isEnabled = ok; it.alpha = if (ok) 1f else 0.4f }
        suppress = true
        perfSwitch.isChecked = prefs.getBoolean("active", false); speedSwitch.isChecked = prefs.getBoolean("speed", false); flagSwitch.isChecked = prefs.getBoolean("speedflag", false); fpsSwitch.isChecked = prefs.getBoolean("gamefps", false); hzSwitch.isChecked = prefs.getBoolean("showhz", false)
        suppress = false
        updateChips()
        if (ok && checkJoyose) { checkJoyoseStatus(false); checkPowerStatus(false); syncFlag(); syncFps(); syncDrivers(); readDpi() }
    }

    private fun sh(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }

    private fun bg(title: String, recheck: Boolean = false, block: () -> String) {
        log.text = "$title…"
        Thread {
            val r = try { block() } catch (e: Throwable) { "Lỗi: ${e.message}" }
            runOnUiThread {
                log.text = "$title\n$r"
                if (r.contains("❌") || r.startsWith("Lỗi")) wiggle(resultPanelRef)
                suppress = true
                perfSwitch.isChecked = prefs.getBoolean("active", false); speedSwitch.isChecked = prefs.getBoolean("speed", false); flagSwitch.isChecked = prefs.getBoolean("speedflag", false); fpsSwitch.isChecked = prefs.getBoolean("gamefps", false); hzSwitch.isChecked = prefs.getBoolean("showhz", false)
                suppress = false
            }
            if (recheck) { checkJoyoseStatus(false); checkPowerStatus(false) }
        }.start()
    }

    // ---------- Gói hệ thống ----------
    private fun checkPkgStatus(p: String, view: TextView, verbose: Boolean) {
        Thread {
            val r = try {
                val list = sh("pm list packages --user 0 $p")
                val dump = if (verbose) sh("dumpsys package $p | grep -i 'installed='") else ""
                Triple(list.contains("package:$p"), list, dump)
            } catch (e: Throwable) { null }
            runOnUiThread {
                if (r == null) {
                    view.text = "Không đọc được trạng thái"
                    view.setTextColor(SUB)
                } else {
                    view.text = if (r.first) "Đang cài" else "Đã gỡ"
                    view.setTextColor(if (r.first) OK else BAD)
                    if (verbose) log.text = "Kiểm tra $p\n[pm list]\n${r.second}\n\n[dumpsys]\n${r.third}"
                }
            }
        }.start()
    }

    private fun checkJoyoseStatus(verbose: Boolean) = checkPkgStatus(pkg, joyoseText, verbose)
    private fun checkPowerStatus(verbose: Boolean) = checkPkgStatus(pkg2, pkText, verbose)

    private fun removeJoyose() = bg("Gỡ Joyose", true) { sh("pm uninstall --user 0 $pkg") }
    private fun installJoyose() = bg("Cài lại Joyose", true) { sh("pm install-existing --user 0 $pkg") }

    private fun confirmRemovePower() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Gỡ Pin và hiệu suất?")
            .setMessage("Có thể mất: tiết kiệm pin, quản lý ứng dụng chạy nền, một số chế độ hiệu năng; " +
                "trang Pin trong Cài đặt có thể lỗi. Bạn có thể cài lại bằng nút \"Cài lại\".")
            .setPositiveButton("Gỡ") { _, _ ->
                bg("Gỡ Pin và hiệu suất", true) { sh("pm uninstall --user 0 $pkg2") }
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun installPower() = bg("Cài lại Pin và hiệu suất", true) { sh("pm install-existing --user 0 $pkg2") }


    // ---------- Chế độ hiệu năng cao ----------
    private fun enablePerf() = bg("Bật khóa tần số quét") {
        val hz = prefs.getInt("hz", 120)
        if (!prefs.getBoolean("active", false)) {
            // Lưu giá trị gốc để khôi phục
            prefs.edit()
                .putString("o_peak", sh("settings get system peak_refresh_rate"))
                .putString("o_min", sh("settings get system min_refresh_rate"))
                .apply()
        }
        val sb = StringBuilder()
        fun step(label: String, cmd: String) {
            val out = sh(cmd)
            sb.append("• $label").append(if (out.isBlank()) ": OK" else ": $out").append("\n")
        }
        step("Tần số quét tối đa ${hz}Hz", "settings put system peak_refresh_rate $hz.0")
        step("Tần số quét tối thiểu ${hz}Hz", "settings put system min_refresh_rate $hz.0")
        prefs.edit().putBoolean("active", true).apply()
        sb.append("\nĐã bật. Tắt công tắc để khôi phục như ban đầu.")
        sb.toString()
    }

    private fun restorePerf() = bg("Khôi phục bình thường") {
        val sb = StringBuilder()
        fun restoreSetting(key: String, saved: String?) {
            val cmd = if (saved.isNullOrBlank() || saved == "null") "settings delete system $key"
            else "settings put system $key $saved"
            val out = sh(cmd)
            sb.append("• $key → ${if (saved.isNullOrBlank() || saved == "null") "mặc định" else saved}")
                .append(if (out.isBlank() || out.startsWith("Deleted")) "" else " ($out)").append("\n")
        }
        restoreSetting("peak_refresh_rate", prefs.getString("o_peak", null))
        restoreSetting("min_refresh_rate", prefs.getString("o_min", null))
        sh("cmd thermalservice reset") // dọn trạng thái nhiệt cũ nếu còn
        prefs.edit().putBoolean("active", false).apply()
        sb.append("\nĐã khôi phục.")
        sb.toString()
    }


    // ---------- Speed mode (như SetEdit) ----------
    private fun enableSpeed() = bg("Bật tăng tốc hoạt ảnh") {
        val sc = prefs.getString("scale", "0.5") ?: "0.5"
        if (!prefs.getBoolean("speed", false)) {
            val e = prefs.edit()
            animKeys.forEach { e.putString("o_$it", sh("settings get global $it")) }
            e.apply()
        }
        val sb = StringBuilder()
        animKeys.forEach { k ->
            val out = sh("settings put global $k $sc")
            val now = sh("settings get global $k")
            sb.append("• $k = $now").append(if (out.isBlank()) "" else " ($out)").append("\n")
        }
        prefs.edit().putBoolean("speed", true).apply()
        sb.append("\nĐã bật. Tắt công tắc để khôi phục như ban đầu.")
        sb.toString()
    }

    private fun restoreSpeed() = bg("Khôi phục hoạt ảnh") {
        val sb = StringBuilder()
        animKeys.forEach { k ->
            val saved = prefs.getString("o_$k", null)
            val unset = saved.isNullOrBlank() || saved == "null"
            sh(if (unset) "settings delete global $k" else "settings put global $k $saved")
            sb.append("• $k → ${if (unset) "mặc định (1.0)" else saved}\n")
        }
        prefs.edit().putBoolean("speed", false).apply()
        sb.append("\nĐã khôi phục.")
        sb.toString()
    }

    // ---------- speed_mode_enable (Secure) ----------
    private fun setSpeedFlag(on: Boolean) = bg(if (on) "Bật chế độ siêu cấp" else "Tắt chế độ siêu cấp") {
        val v = if (on) "1" else "0"
        val o1 = sh("settings put system speed_mode $v")
        val o2 = sh("settings put secure speed_mode_enable $v")
        val a = sh("settings get system speed_mode")
        val b = sh("settings get secure speed_mode_enable")
        prefs.edit().putBoolean("speedflag", a == "1" && b == "1").apply()
        "• system speed_mode = $a" + (if (o1.isBlank()) "" else " ($o1)") + "\n" +
            "• secure speed_mode_enable = $b" + (if (o2.isBlank()) "" else " ($o2)") + "\n" +
            (if (a == v && b == v) "✅ Đã ghi đúng. Kiểm tra: Tùy chọn nhà phát triển → Chế độ siêu cấp"
            else "❌ Có giá trị không đổi — hệ thống có thể chặn")
    }

    private fun syncFlag() {
        Thread {
            val a = try { sh("settings get system speed_mode") } catch (e: Throwable) { "" }
            val b = try { sh("settings get secure speed_mode_enable") } catch (e: Throwable) { "" }
            if (a.isNotEmpty() || b.isNotEmpty()) {
                val on = a == "1" && b == "1"
                prefs.edit().putBoolean("speedflag", on).apply()
                runOnUiThread {
                    suppress = true; flagSwitch.isChecked = on; suppress = false
                }
            }
        }.start()
    }

    // ---------- Thông báo nhiệt độ ----------
    private fun startTemp() {
        val i = Intent(this, TempService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun stopTemp() { stopService(Intent(this, TempService::class.java)) }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (granted) {
                prefs.edit().putBoolean("temp", true).apply(); startTemp()
            } else {
                suppress = true; tempSwitch.isChecked = false; suppress = false
                log.text = "Cần cấp quyền Thông báo cho tđ.exe để hiện nhiệt độ"
            }
        }
    }

    // ---------- Thông tin thiết bị ----------
    private fun prop(n: String): String = try {
        Runtime.getRuntime().exec(arrayOf("getprop", n)).inputStream.bufferedReader().readText().trim()
    } catch (e: Throwable) { "" }

    private fun loadDevice() {
        Thread {
            val market = listOf("ro.product.marketname", "ro.product.vendor.marketname")
                .map { prop(it) }.firstOrNull { it.isNotBlank() }
            val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
            val name = market ?: "$brand ${Build.MODEL}"
            val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() &&
                !Build.SOC_MODEL.equals("unknown", true)) Build.SOC_MODEL else null
            val ramKb = try {
                java.io.File("/proc/meminfo").readLines().firstOrNull { it.startsWith("MemTotal:") }
                    ?.replace(Regex("[^0-9]"), "")?.toLongOrNull()
            } catch (e: Throwable) { null }
            val ram = ramKb?.let { String.format(java.util.Locale.US, "RAM %.1f GB", it / 1048576.0) }
            val info = listOfNotNull(Build.MODEL, "Android ${Build.VERSION.RELEASE}", soc, ram).joinToString("  •  ")
            runOnUiThread { deviceName.text = name; deviceInfo.text = info }
        }.start()
    }

    // ---------- Tăng tốc máy (có số liệu trước/sau) ----------
    private fun memKb(key: String): Long =
        sh("grep $key: /proc/meminfo").replace(Regex("[^0-9]"), "").toLongOrNull() ?: 0L

    private fun freeStorageKb(): Long =
        sh("df -k /data | tail -1").trim().split(Regex("\\s+")).getOrNull(3)?.toLongOrNull() ?: 0L

    private fun freeRam() = bg("Giải phóng RAM") {
        val before = memKb("MemAvailable")
        sh("am kill-all")
        Thread.sleep(1500)
        val after = memKb("MemAvailable")
        "RAM trống trước: ${before / 1024} MB\n" +
            "RAM trống sau:   ${after / 1024} MB\n" +
            "Chênh lệch:      ${(after - before) / 1024} MB\n\n" +
            "Ứng dụng nền bị đóng sẽ tự mở lại khi bạn dùng, nên lợi ích chỉ kéo dài ngắn."
    }

    private fun trimCaches() = bg("Dọn bộ nhớ đệm") {
        val before = freeStorageKb()
        val out = sh("pm trim-caches 999G")
        val after = freeStorageKb()
        "Bộ nhớ trống trước: ${before / 1024} MB\n" +
            "Bộ nhớ trống sau:   ${after / 1024} MB\n" +
            "Đã giải phóng:      ${(after - before) / 1024} MB" +
            (if (out.isBlank()) "" else "\n$out")
    }

    private fun compileApps() = bg("Tối ưu ứng dụng (mất vài phút, đừng thoát app)") {
        val out = sh("cmd package compile -m speed-profile -a")
        "Hoàn tất.\n" + out.lines().takeLast(6).joinToString("\n")
    }

    // ---------- Tắt FPS mặc định của game ----------
    // Dò khóa trên máy thật cho thấy công tắc đổi debug.graphics.game_default_frame_rate.disabled
    // false → true khi BẬT "Tắt tốc độ khung hình mặc định cho trò chơi" (giá trị debug.* mất sau khi khởi động lại)
    private fun setGameFps(disable: Boolean) = bg(if (disable) "Tắt giới hạn FPS mặc định" else "Bật lại giới hạn FPS mặc định") {
        val v = if (disable) "true" else "false"
        val out = sh("setprop $fpsProp $v")
        val now = sh("getprop $fpsProp")
        prefs.edit().putBoolean("gamefps", now == "true").apply()
        "• $fpsProp = ${now.ifBlank { "(trống)" }}" + (if (out.isBlank()) "" else " ($out)") + "\n" +
            (if (now == v) "✅ Đã ghi đúng giá trị $v"
            else "❌ Máy chặn lệnh này. Bấm \"Mở Tùy chọn nhà phát triển\" để bật tay.") +
            "\nLưu ý: giá trị này mất sau khi khởi động lại máy, cần bật lại."
    }

    private fun syncFps() {
        Thread {
            val v = try { sh("getprop $fpsProp") } catch (e: Throwable) { null }
            if (v != null) {
                prefs.edit().putBoolean("gamefps", v == "true").apply()
                runOnUiThread { suppress = true; fpsSwitch.isChecked = v == "true"; suppress = false }
            }
        }.start()
    }

    // ---------- Trình điều khiển đồ họa theo từng game ----------
    // Android 12+ dùng khóa updatable_driver_*, bản cũ dùng game_driver_* → ghi cả hai cho chắc.
    private val outKeys = listOf("updatable_driver_production_opt_out_apps", "game_driver_opt_out_apps")
    private val inKeys = listOf(
        "updatable_driver_production_opt_in_apps", "updatable_driver_prerelease_opt_in_apps",
        "game_driver_opt_in_apps", "game_driver_prerelease_opt_in_apps"
    )

    private fun getList(key: String): MutableList<String> {
        val v = sh("settings get global $key").trim()
        return if (v.isBlank() || v == "null") mutableListOf()
        else v.split(",", ";").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
    }

    private fun putList(key: String, list: List<String>) {
        if (list.isEmpty()) sh("settings delete global $key")
        else sh("settings put global $key ${list.joinToString(",")}")
    }

    private fun setDriver(pk: String, name: String, system: Boolean) =
        bg("$name → " + (if (system) "Hệ thống" else "Mặc định")) {
            val sb = StringBuilder()
            outKeys.forEach { k ->
                val l = getList(k)
                val had = l.contains(pk)
                l.remove(pk)
                if (system) l.add(pk)
                if (had != system || system) putList(k, l)
            }
            inKeys.forEach { k ->
                val l = getList(k)
                if (l.remove(pk)) putList(k, l)
            }
            var ok = true
            outKeys.forEach { k ->
                val now = getList(k)
                if (now.contains(pk) != system) ok = false
                sb.append("• $k = ${now.joinToString(",").ifBlank { "(trống)" }}\n")
            }
            runOnUiThread { driverState[pk] = system && ok; updateDriverUi() }
            sb.append(if (ok) "\n✅ Đã ghi. Thoát hẳn game rồi mở lại. Nếu mục Cài đặt vẫn báo Mặc định, hãy dùng Dò khóa bên dưới."
            else "\n❌ Giá trị không đổi — hệ thống có thể chặn")
            sb.toString()
        }

    private fun syncDrivers() {
        Thread {
            try {
                val pk = sh("pm list packages --user 0 com.dts.freefire")
                val sys = outKeys.flatMap { getList(it) }.toSet()
                runOnUiThread {
                    games.forEach { (p, _) ->
                        driverState[p] = sys.contains(p)
                        installedState[p] = pk.contains("package:$p")
                    }
                    updateDriverUi()
                }
            } catch (e: Throwable) { }
        }.start()
    }

    // ---------- Dò khóa: so sánh Settings trước/sau khi bạn tự đổi bằng tay ----------
    private var snapA: Map<String, String>? = null

    private fun snapshot(): Map<String, String> {
        val m = linkedMapOf<String, String>()
        listOf("global", "secure", "system").forEach { t ->
            sh("settings list $t").lines().forEach { ln ->
                val i = ln.indexOf('=')
                if (i > 0) m["$t:${ln.substring(0, i)}"] = ln.substring(i + 1)
            }
        }
        val keep = Regex("graphics|game|frame|driver|angle", RegexOption.IGNORE_CASE)
        sh("getprop").lines().forEach { ln ->
            val r = Regex("^\\[(.*?)\\]: \\[(.*)\\]$").find(ln.trim())
            if (r != null && keep.containsMatchIn(r.groupValues[1])) m["prop:" + r.groupValues[1]] = r.groupValues[2]
        }
        return m
    }

    private fun takeSnap() = bg("Chụp trạng thái") {
        val m = snapshot()
        snapA = m
        "Đã chụp ${m.size} mục.\nBây giờ vào Cài đặt, TỰ bật công tắc hoặc chọn trình điều khiển, " +
            "rồi quay lại bấm \"2. So sánh\"."
    }

    private fun compareSnap() = bg("So sánh") {
        val a = snapA
        if (a == null) "Chưa chụp ở bước 1." else {
            val b = snapshot()
            val noise = Regex("time|last|elapsed|count|uptime|date|seq|bytes|stamp", RegexOption.IGNORE_CASE)
            val lines = mutableListOf<String>()
            (a.keys + b.keys).toSortedSet().forEach { k ->
                val x = a[k]; val y = b[k]
                if (x != y && !noise.containsMatchIn(k)) {
                    lines.add("$k: ${(x ?: "(không có)").take(120)} → ${(y ?: "(đã xóa)").take(120)}")
                }
            }
            if (lines.isEmpty()) "Không thấy khóa nào đổi."
            else lines.take(40).joinToString("\n") + (if (lines.size > 40) "\n… (+${lines.size - 40} dòng)" else "")
        }
    }

    private fun updateDriverUi() {
        games.forEach { (p, _) ->
            val sys = driverState[p] == true
            val inst = installedState[p] == true
            driverStatus[p]?.text = (if (inst) "Đã cài" else "Chưa cài trên máy") +
                "  •  đang dùng: " + (if (sys) "Hệ thống" else "Mặc định")
            driverChips[p]?.forEachIndexed { i, c -> chipStyle(c, (i == 1) == sys) }
        }
    }

    // ---------- Fix lag: bật tất cả + gỡ Joyose và Pin và hiệu suất ----------
    private fun confirmFixLag() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Fix lag?")
            .setMessage("Sẽ gỡ Joyose và Pin và hiệu suất, khóa tần số quét, bật tăng tốc hoạt ảnh, chế độ siêu cấp, " +
                "tắt FPS mặc định của game, đặt Free Fire sang trình điều khiển Hệ thống và giải phóng RAM.\n\n" +
                "Có thể mất tiết kiệm pin và quản lý chạy nền. Bấm \"Hoàn tác\" để trả lại như cũ.")
            .setPositiveButton("Bật") { _, _ -> fixLag() }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun fixLag() = bg("Fix lag", true) {
        val sb = StringBuilder()
        fun step(label: String, cmd: String) {
            val o = sh(cmd)
            sb.append("• $label: ").append(if (o.isBlank()) "OK" else o.take(80)).append("\n")
        }

        step("Gỡ Joyose", "pm uninstall --user 0 $pkg")
        step("Gỡ Pin và hiệu suất", "pm uninstall --user 0 $pkg2")

        // Khóa tần số quét
        val hz = prefs.getInt("hz", 120)
        if (!prefs.getBoolean("active", false)) {
            prefs.edit()
                .putString("o_peak", sh("settings get system peak_refresh_rate"))
                .putString("o_min", sh("settings get system min_refresh_rate"))
                .apply()
        }
        step("Tần số quét ${hz}Hz", "settings put system peak_refresh_rate $hz.0 && settings put system min_refresh_rate $hz.0")
        prefs.edit().putBoolean("active", true).apply()

        // Hoạt ảnh
        val sc = prefs.getString("scale", "0.5") ?: "0.5"
        if (!prefs.getBoolean("speed", false)) {
            val e = prefs.edit()
            animKeys.forEach { e.putString("o_$it", sh("settings get global $it")) }
            e.apply()
        }
        step("Hoạt ảnh ${sc}x", animKeys.joinToString(" && ") { "settings put global $it $sc" })
        prefs.edit().putBoolean("speed", true).apply()

        // Chế độ siêu cấp
        step("Chế độ siêu cấp", "settings put system speed_mode 1 && settings put secure speed_mode_enable 1")
        prefs.edit().putBoolean(
            "speedflag",
            sh("settings get system speed_mode") == "1" && sh("settings get secure speed_mode_enable") == "1"
        ).apply()

        // FPS mặc định của game
        step("Tắt FPS mặc định của game", "setprop $fpsProp true")
        prefs.edit().putBoolean("gamefps", sh("getprop $fpsProp") == "true").apply()

        // Trình điều khiển đồ họa cho Free Fire đã cài
        val installed = sh("pm list packages --user 0 com.dts.freefire")
        games.forEach { (pk, name) ->
            if (installed.contains("package:$pk")) {
                outKeys.forEach { k ->
                    val l = getList(k)
                    if (!l.contains(pk)) { l.add(pk); putList(k, l) }
                }
                inKeys.forEach { k -> val l = getList(k); if (l.remove(pk)) putList(k, l) }
                sb.append("• $name: trình điều khiển Hệ thống\n")
            }
        }

        step("Giải phóng RAM", "am kill-all")
        syncDrivers()
        sb.append("\nHoàn tất. Khởi động lại máy rồi bấm Xác minh thực tế để xem số Hz.")
        sb.toString()
    }

    private fun undoFixLag() = bg("Hoàn tác fix lag", true) {
        val sb = StringBuilder()
        fun step(label: String, cmd: String) {
            val o = sh(cmd)
            sb.append("• $label: ").append(if (o.isBlank()) "OK" else o.take(80)).append("\n")
        }
        fun restore(table: String, key: String, saved: String?) {
            val unset = saved.isNullOrBlank() || saved == "null"
            sh(if (unset) "settings delete $table $key" else "settings put $table $key $saved")
        }

        step("Cài lại Joyose", "pm install-existing --user 0 $pkg")
        step("Cài lại Pin và hiệu suất", "pm install-existing --user 0 $pkg2")

        restore("system", "peak_refresh_rate", prefs.getString("o_peak", null))
        restore("system", "min_refresh_rate", prefs.getString("o_min", null))
        sb.append("• Tần số quét: đã khôi phục\n")
        animKeys.forEach { restore("global", it, prefs.getString("o_$it", null)) }
        sb.append("• Hoạt ảnh: đã khôi phục\n")
        step("Tắt chế độ siêu cấp", "settings put system speed_mode 0 && settings put secure speed_mode_enable 0")
        step("Bật lại FPS mặc định của game", "setprop $fpsProp false")
        sh("cmd thermalservice reset")

        games.forEach { (pk, _) ->
            outKeys.forEach { k -> val l = getList(k); if (l.remove(pk)) putList(k, l) }
        }
        sb.append("• Trình điều khiển Free Fire: Mặc định\n")

        prefs.edit().putBoolean("active", false).putBoolean("speed", false)
            .putBoolean("speedflag", false).putBoolean("gamefps", false).apply()
        syncDrivers()
        sb.append("\nĐã hoàn tác. Khởi động lại máy để mọi thứ về đúng như ban đầu.")
        sb.toString()
    }

    // ---------- Cập nhật qua GitHub Release ----------
    private val repo = "ZOKOTV/Bu.exe"
    private val apkUrl = "https://github.com/ZOKOTV/Bu.exe/releases/latest/download/td-exe.apk"

    @Suppress("DEPRECATION")
    private fun currentVersionCode(): Int = try {
        val pi = packageManager.getPackageInfo(packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
    } catch (e: Throwable) { 0 }

    private fun checkUpdate() = bg("Kiểm tra cập nhật") {
        val cur = currentVersionCode()
        val c = java.net.URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "td-exe")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        val json = c.inputStream.bufferedReader().use { it.readText() }
        val tag = Regex("\"tag_name\"\\s*:\\s*\"([^\"]+)\"").find(json)?.groupValues?.get(1)
        val latest = tag?.removePrefix("v")?.toIntOrNull()
        if (latest == null) {
            "Không đọc được bản mới nhất (tag: $tag)"
        } else if (latest > cur) {
            runOnUiThread {
                android.app.AlertDialog.Builder(this)
                    .setTitle("Có bản mới v$latest")
                    .setMessage("Bạn đang dùng v$cur. Bấm Tải để tải file APK, mở file đó để cài đè lên bản cũ.")
                    .setPositiveButton("Tải") { _, _ -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(apkUrl))) }
                    .setNegativeButton("Để sau", null)
                    .show()
            }
            "Có bản mới: v$latest (đang dùng v$cur)"
        } else {
            "Bạn đang dùng bản mới nhất (v$cur)."
        }
    }

    // ---------- Thống kê ẩn danh (có xin phép, tắt được) ----------
    private fun anonId(): String = prefs.getString("aid", null)
        ?: java.util.UUID.randomUUID().toString().also { prefs.edit().putString("aid", it).apply() }

    private fun setPingStatus(msg: String) {
        prefs.edit().putString("last_ping", msg).apply()
        runOnUiThread { pingStatus?.text = msg }
    }

    /** Gọi địa chỉ thống kê bằng GET (Apps Script nhận GET công khai ổn định hơn POST). */
    private fun callEndpoint(query: String): String {
        val base = BuildConfig.ANALYTICS_URL
        val target = base + (if (base.contains("?")) "&" else "?") + query
        val c = java.net.URL(target).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "td-exe")
        val code = c.responseCode
        val host = c.url.host
        val body = (try {
            (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }
        } catch (e: Throwable) { null }) ?: ""
        c.disconnect()
        return "HTTP $code (qua $host) " + body.replace(Regex("\\s+"), " ").take(60)
    }

    private fun pingAnalytics() {
        if (BuildConfig.ANALYTICS_URL.isBlank() || !prefs.getBoolean("analytics", false)) return
        val q = "action=ping&id=" + anonId() + "&v=" + currentVersionCode()
        Thread {
            val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
            try {
                setPingStatus("Lần gửi cuối $time: " + callEndpoint(q))
            } catch (e: Throwable) {
                setPingStatus("Gửi lỗi $time: ${e.javaClass.simpleName} ${e.message}")
            }
        }.start()
    }

    /** Gửi đúng một lượt đếm "từ chối", không kèm mã hay thông tin nào (đã nói rõ trong hộp thoại). */
    private fun sendDecline() {
        if (BuildConfig.ANALYTICS_URL.isBlank() || prefs.getBoolean("decline_sent", false)) return
        prefs.edit().putBoolean("decline_sent", true).apply()
        Thread {
            try { callEndpoint("action=decline") } catch (e: Throwable) { }
        }.start()
    }

    private fun askConsent() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Thống kê ẩn danh")
            .setMessage("tđ.exe gửi một mã ngẫu nhiên (không gắn với tên hay thiết bị của bạn) và số phiên bản " +
                "mỗi lần mở app, để tác giả biết có bao nhiêu người dùng.\n\n" +
                "Không thu thập tên, số điện thoại, vị trí hay dữ liệu cá nhân. " +
                "Bạn có thể tắt bất cứ lúc nào ở mục Thống kê ẩn danh.\n\n" +
                "Nếu bấm \"Không\": app chỉ gửi đúng MỘT lượt đếm \"đã từ chối\", không kèm mã hay thông tin nào, " +
                "rồi không gửi gì nữa.")
            .setCancelable(false)
            .setPositiveButton("Đồng ý") { _, _ ->
                prefs.edit().putBoolean("analytics", true).apply()
                suppress = true; privacySwitch?.isChecked = true; suppress = false
                pingAnalytics()
            }
            .setNegativeButton("Không") { _, _ ->
                prefs.edit().putBoolean("analytics", false).apply()
                suppress = true; privacySwitch?.isChecked = false; suppress = false
                sendDecline()
            }
            .show()
    }

    // ---------- Độ phân giải và DPI ----------
    /** Trả về [rộng hiện tại, cao hiện tại, DPI hiện tại, rộng gốc, cao gốc, DPI gốc] hoặc null. */
    private fun readDisplayNow(): IntArray? {
        val sz = sh("wm size")
        val dn = sh("wm density")
        val phys = Regex("Physical size: (\\d+)x(\\d+)").find(sz) ?: return null
        val ov = Regex("Override size: (\\d+)x(\\d+)").find(sz)
        val pd = Regex("Physical density: (\\d+)").find(dn)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        val od = Regex("Override density: (\\d+)").find(dn)?.groupValues?.get(1)?.toIntOrNull()
        val pw = phys.groupValues[1].toInt()
        val ph = phys.groupValues[2].toInt()
        val cw = ov?.groupValues?.get(1)?.toIntOrNull() ?: pw
        val ch = ov?.groupValues?.get(2)?.toIntOrNull() ?: ph
        // Giá trị Cài đặt thật sự hiển thị: "am get-config" in ra dạng sw446dp
        val sw = Regex("sw(\\d+)dp").find(sh("am get-config"))?.groupValues?.get(1)?.toIntOrNull() ?: -1
        return intArrayOf(cw, ch, od ?: pd, pw, ph, pd, sw)
    }

    private fun readDpi(fill: Boolean = false) {
        Thread {
            val r = try { readDisplayNow() } catch (e: Throwable) { null }
            if (r != null) {
                runOnUiThread {
                    curW = r[0]; curH = r[1]; curD = r[2]; curSw = r[6]
                    physW = r[3]; physH = r[4]; physD = r[5]
                    if (fill || etW.text.isNullOrBlank()) fillFields()
                    updateDpiUi()
                }
            }
        }.start()
    }

    private fun fillFields() {
        fieldsBusy = true
        etW.setText(curW.toString())
        etH.setText(curH.toString())
        etD.setText(curD.toString())
        // Ô dp hiện đúng số hệ thống đang báo (am get-config); nếu không đọc được mới dùng công thức
        if (curSw >= 0) etS.setText(curSw.toString())
        fieldsBusy = false
        if (curSw < 0) swFromDpi()
    }

    /** Nhỏ nhất của (Rộng, Cao) trong các ô nhập, hoặc null nếu chưa nhập đủ. */
    private fun minSide(): Int? {
        val w = etW.text.toString().toIntOrNull()
        val h = etH.text.toString().toIntOrNull()
        return if (w == null || h == null) null else minOf(w, h)
    }

    /** Độ rộng nhỏ nhất (dp) = cạnh ngắn × 160 ÷ DPI (Android làm tròn xuống). Tỉ lệ NGHỊCH với DPI. */
    private fun swFromDpi() {
        val m = minSide() ?: return
        val d = etD.text.toString().toIntOrNull() ?: return
        if (d <= 0) return
        fieldsBusy = true
        etS.setText((m * 160 / d).toString())
        fieldsBusy = false
    }

    private fun dpiFromSw() {
        val m = minSide() ?: return
        val n = etS.text.toString().toIntOrNull() ?: return
        if (n <= 0) return
        val x = m * 160
        val base = x / n
        val d = listOf(base, base - 1, base + 1).firstOrNull { it > 0 && x / it == n } ?: base
        fieldsBusy = true
        etD.setText(d.toString())
        fieldsBusy = false
    }

    private fun updateDpiUi() {
        dpiInfo.text = if (physW == 0) "Chưa đọc được thông số màn hình (cần Shizuku)"
        else "Hiện tại: ${curW}×${curH} • ${curD} DPI • ${if (curSw >= 0) curSw else minOf(curW, curH) * 160 / curD} dp (Cài đặt)\nHệ thống báo: ${resources.configuration.smallestScreenWidthDp} dp\nGốc: ${physW}×${physH} • ${physD} DPI • ${minOf(physW, physH) * 160 / physD} dp"
    }

    private fun sizeCmd(w: Int, h: Int) = if (w == physW && h == physH) "wm size reset" else "wm size ${w}x$h"
    private fun densCmd(d: Int) = if (d == physD) "wm density reset" else "wm density $d"

    private fun applyDisplay() {
        if (physW == 0) { log.text = "Chưa đọc được thông số màn hình — kiểm tra Shizuku"; return }
        val w = etW.text.toString().toIntOrNull()
        val h = etH.text.toString().toIntOrNull()
        val d = etD.text.toString().toIntOrNull()
        if (w == null || h == null || d == null) { log.text = "Hãy nhập đủ Rộng, Cao và dp"; return }
        if (w < 320 || h < 320 || w > physW * 2 || h > physH * 2) {
            log.text = "Rộng và Cao phải từ 320 đến gấp đôi kích thước gốc"; return
        }
        if (d < 120 || d > 800) { log.text = "DPI tính ra phải từ 120 đến 800"; return }
        val tdp = etS.text.toString().toIntOrNull() ?: -1
        // Nếu người dùng nhập theo dp: lấy số dp mà Cài đặt báo làm chuẩn và tự chỉnh DPI cho khớp
        val useDp = lastEdit == 'S' && tdp > 0
        val sizeChanged = w != curW || h != curH
        val densChanged = if (useDp && curSw >= 0 && !sizeChanged) tdp != curSw else d != curD
        if (!sizeChanged && !densChanged) { log.text = "Không có gì thay đổi"; return }
        val pw = curW; val ph = curH; val pd = curD
        log.text = "Đang áp dụng…"
        Thread {
            val out = StringBuilder()
            if (sizeChanged) out.append(sh(sizeCmd(w, h))).append("\n")
            if (densChanged) out.append(sh(densCmd(d))).append("\n")
            Thread.sleep(700)
            var r = try { readDisplayNow() } catch (e: Throwable) { null }
            var tries = 0
            if (useDp && r != null && r[6] >= 0) {
                var dd = r[2]
                while (tries < 8 && r != null && r[6] >= 0 && r[6] != tdp) {
                    dd += if (r[6] > tdp) 1 else -1
                    sh(densCmd(dd))
                    Thread.sleep(700)
                    r = try { readDisplayNow() } catch (e: Throwable) { null }
                    tries++
                }
            }
            val fin = r
            runOnUiThread {
                if (fin != null) {
                    curW = fin[0]; curH = fin[1]; curD = fin[2]; curSw = fin[6]
                    fieldsBusy = true
                    etD.setText(fin[2].toString())
                    fieldsBusy = false
                    updateDpiUi()
                }
                val sizeOk = fin != null && fin[0] == w && fin[1] == h
                val dpOk = fin != null && (if (useDp && fin[6] >= 0) fin[6] == tdp else fin[2] == d)
                val real = if (fin != null) "${fin[0]}×${fin[1]} • ${fin[2]} DPI • Cài đặt hiện ${fin[6]} dp" else "?"
                if (sizeOk && dpOk) {
                    log.text = "Đã đổi: ${pw}×${ph} • $pd DPI → $real" +
                        (if (tries > 0) "\n(đã tự chỉnh DPI $tries lần để dp khớp với Cài đặt)" else "")
                    showDisplayConfirm(pw, ph, pd)
                } else {
                    log.text = "❌ Chưa đúng như yêu cầu. Hiện: $real\n" + out.toString().trim()
                }
            }
        }.start()
    }

    /** Hộp thoại xác nhận có đếm ngược: nếu giao diện hỏng không bấm được thì tự hoàn lại. */
    private fun showDisplayConfirm(pw: Int, ph: Int, pd: Int) {
        var left = 15
        val dlg = android.app.AlertDialog.Builder(this)
            .setTitle("Giữ cài đặt màn hình mới?")
            .setMessage("Tự khôi phục sau $left giây nếu bạn không xác nhận.")
            .setCancelable(false)
            .setPositiveButton("Giữ") { _, _ ->
                dpiHandler.removeCallbacksAndMessages(null)
                log.text = "Đã giữ: ${curW}×${curH} • $curD DPI"
            }
            .setNegativeButton("Hoàn lại") { _, _ -> revertDisplay(pw, ph, pd) }
            .create()
        dlg.show()
        val tick = object : Runnable {
            override fun run() {
                if (!dlg.isShowing) return
                left--
                if (left <= 0) {
                    dlg.dismiss()
                    revertDisplay(pw, ph, pd)
                } else {
                    dlg.setMessage("Tự khôi phục sau $left giây nếu bạn không xác nhận.")
                    dpiHandler.postDelayed(this, 1000)
                }
            }
        }
        dpiHandler.postDelayed(tick, 1000)
    }

    private fun revertDisplay(pw: Int, ph: Int, pd: Int) {
        dpiHandler.removeCallbacksAndMessages(null)
        Thread {
            sh(sizeCmd(pw, ph))
            sh(densCmd(pd))
            runOnUiThread {
                curW = pw; curH = ph; curD = pd
                fillFields(); updateDpiUi()
                log.text = "Đã hoàn lại: ${pw}×${ph} • $pd DPI"
                readDpi(true)
            }
        }.start()
    }

    private fun resetDisplay() = bg("Đặt lại độ phân giải và DPI gốc") {
        sh("wm size reset")
        sh("wm density reset")
        val r = readDisplayNow()
        runOnUiThread {
            if (r != null) { curW = r[0]; curH = r[1]; curD = r[2]; curSw = r[6] }
            fillFields(); updateDpiUi()
        }
        "Đã về gốc: ${physW}×${physH} • $physD DPI"
    }

    // ---------- Dồn tài nguyên cho game ----------
    private fun boostGames() = bg("Dồn tài nguyên cho game") {
        val sb = StringBuilder()
        val installed = sh("pm list packages --user 0 com.dts.freefire")
        val targets = games.filter { installed.contains("package:" + it.first) }
        if (targets.isEmpty()) {
            "Chưa thấy Free Fire hay Free Fire MAX cài trên máy."
        } else {
            val before = memKb("MemAvailable")
            targets.forEach { (pk, name) ->
                sb.append("$name ($pk)\n")
                fun step(label: String, cmd: String) {
                    val o = sh(cmd)
                    sb.append("  • $label: ").append(if (o.isBlank()) "OK" else o.take(100)).append("\n")
                }
                step("Chế độ Game: Hiệu năng", "cmd game mode performance $pk")
                step("Miễn hạn chế pin", "cmd deviceidle whitelist +$pk")
                step("Ưu tiên chạy: active", "am set-standby-bucket $pk active")
                sb.append("  • Các chế độ Game của máy: ").append(sh("cmd game list-modes $pk").take(160)).append("\n")
            }
            sh("am kill-all")
            Thread.sleep(1500)
            val after = memKb("MemAvailable")
            sb.append("\nRAM trống: ${before / 1024} MB → ${after / 1024} MB\n")
            sb.append("Mở game ngay để tận dụng RAM vừa giải phóng.")
            sb.toString()
        }
    }

    private fun undoBoost() = bg("Hoàn lại cài đặt game") {
        val sb = StringBuilder()
        val installed = sh("pm list packages --user 0 com.dts.freefire")
        val targets = games.filter { installed.contains("package:" + it.first) }
        if (targets.isEmpty()) {
            "Chưa thấy Free Fire hay Free Fire MAX cài trên máy."
        } else {
            targets.forEach { (pk, name) ->
                val o = sh("cmd game mode standard $pk")
                sh("cmd deviceidle whitelist -$pk")
                sb.append("• $name: ").append(if (o.isBlank()) "đã về chế độ Game tiêu chuẩn" else o.take(100)).append("\n")
            }
            sb.toString()
        }
    }

    // ---------- Lớp phủ nổi hiện tốc độ làm mới (quay màn vẫn thấy) ----------
    private fun toggleOverlay(on: Boolean) {
        if (!on) {
            prefs.edit().putBoolean("showhz", false).apply()
            stopService(Intent(this, OverlayService::class.java))
            return
        }
        if (android.provider.Settings.canDrawOverlays(this)) {
            startOverlay()
            return
        }
        // Chưa có quyền "Hiển thị trên ứng dụng khác": thử cấp bằng Shizuku, không được thì mở màn hình cấp quyền
        Thread {
            var granted = false
            try {
                if (Shizuku.pingBinder() && hasPerm()) {
                    sh("cmd appops set $packageName SYSTEM_ALERT_WINDOW allow")
                    Thread.sleep(400)
                    granted = android.provider.Settings.canDrawOverlays(this)
                }
            } catch (e: Throwable) { }
            runOnUiThread {
                if (granted) {
                    startOverlay()
                } else {
                    prefs.edit().putBoolean("showhz", false).apply()
                    suppress = true; hzSwitch.isChecked = false; suppress = false
                    log.text = "Cần cấp quyền \"Hiển thị trên ứng dụng khác\" cho tđ.exe. Bật quyền rồi quay lại và bật công tắc lần nữa."
                    startActivity(
                        Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                }
            }
        }.start()
    }

    private fun startOverlay() {
        prefs.edit().putBoolean("showhz", true).apply()
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        log.text = "Đã bật lớp phủ tốc độ làm mới. Nó hiện nổi trên mọi app kể cả game."
    }

    private fun reloadOverlay() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction("reload"))
        }
    }

    private fun updateOverlayChips() {
        val pos = prefs.getInt("ov_pos", 1)
        val size = prefs.getInt("ov_size", 1)
        ovPosChips.forEachIndexed { i, c -> chipStyle(c, i == pos) }
        ovSizeChips.forEachIndexed { i, c -> chipStyle(c, i == size) }
    }

    // ---------- Xác minh thực tế ----------
    private fun verify() = bg("Xác minh thực tế") {
        val sb = StringBuilder()
        val active = prefs.getBoolean("active", false)
        val target = prefs.getInt("hz", 120)
        sb.append(if (active) "Khóa tần số quét: ĐANG BẬT\n\n" else "Khóa tần số quét: đang tắt (chỉ hiện số liệu hiện tại)\n\n")

        // 1. Tần số quét
        val peak = sh("settings get system peak_refresh_rate")
        val min = sh("settings get system min_refresh_rate")
        val disp = sh("dumpsys display | grep -E 'mActiveModeId|DisplayModeRecord'")
        val id = Regex("mActiveModeId=(\\d+)").find(disp)?.groupValues?.get(1)
        val fps = id?.let { Regex("id=$it,[^}]*?fps=([0-9.]+)").find(disp)?.groupValues?.get(1)?.toFloatOrNull() }
        sb.append("1) Tần số quét\n")
        sb.append("   Cài đặt: peak=$peak, min=$min\n")
        if (fps != null) {
            sb.append("   Màn hình thực tế: ${fps}Hz\n")
            if (active) sb.append(
                if (fps >= target - 1f) "   ✅ HOẠT ĐỘNG: màn hình đang chạy đúng ${target}Hz\n"
                else "   ❌ KHÔNG HOẠT ĐỘNG: màn hình ở ${fps}Hz, chưa đạt ${target}Hz (ROM bỏ qua cài đặt)\n"
            )
        } else {
            sb.append("   ⚠ Không đọc được tần số thực tế từ máy này\n")
            sb.append("   ${disp.take(300)}\n")
        }

        // 2. Nhiệt độ pin
        val bt = Regex("temperature: (\\d+)").find(sh("dumpsys battery"))?.groupValues?.get(1)?.toIntOrNull()
        sb.append("\n2) Nhiệt độ pin: ${if (bt != null) "${bt / 10.0}°C" else "không đọc được"}\n")

        // 3. Joyose (đếm tiến trình khớp tên chính xác; ký tự [e] để lệnh grep không tự khớp chính nó)
        val n = sh("ps -A -o NAME | grep -c 'com.xiaomi.joyos[e]'").trim().toIntOrNull()
        sb.append("\n3) Tiến trình Joyose: ")
        sb.append(when {
            n == null -> "⚠ không đọc được"
            n == 0 -> "✅ không chạy"
            else -> "đang chạy ($n tiến trình)"
        })
        sb.append("\n")

        // 4. Hoạt ảnh
        val av = animKeys.map { sh("settings get global $it") }
        sb.append("\n4) Tăng tốc hoạt ảnh\n   ${av.joinToString(" / ")}\n")
        if (prefs.getBoolean("speed", false)) {
            val sc = (prefs.getString("scale", "0.5") ?: "0.5").toFloat()
            val ok = av.all { it.toFloatOrNull() == sc }
            sb.append(if (ok) "   ✅ HOẠT ĐỘNG: cả 3 giá trị đã đổi\n" else "   ❌ Có giá trị chưa được đổi\n")
        }

        // 5. Chế độ siêu cấp
        sb.append("\n5) Chế độ siêu cấp\n   system speed_mode = ${sh("settings get system speed_mode")}\n   secure speed_mode_enable = ${sh("settings get secure speed_mode_enable")}\n")

        // 6. FPS mặc định của game
        sb.append("\n6) Giới hạn FPS mặc định của game\n   $fpsProp = ${sh("getprop $fpsProp").ifBlank { "(trống)" }}\n")

        // 7. Trình điều khiển đồ họa
        sb.append("\n7) Trình điều khiển đồ họa (danh sách dùng Hệ thống)\n")
        outKeys.forEach { k -> sb.append("   $k = ${getList(k).joinToString(",").ifBlank { "(trống)" }}\n") }
        sb.toString()
    }

    // ---------- UI: kính + 3D ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(color)
    }

    /** Nền kính: lớp mờ trắng trong suốt + viền sáng mảnh. */
    private fun glass(radius: Int): LayerDrawable {
        val r = dp(radius).toFloat()
        val fill = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x2EFFFFFF, 0x0DFFFFFF)
        ).apply { cornerRadius = r }
        val edge = GradientDrawable().apply {
            cornerRadius = r; setColor(Color.TRANSPARENT); setStroke(dp(1), 0x47FFFFFF)
        }
        return LayerDrawable(arrayOf(fill, edge))
    }

    /** Nút nổi 3D: đáy tối + mặt gradient + vệt bóng phía trên. */
    private fun face3d(top: Int, bottom: Int, depthColor: Int, radius: Int, depth: Int): LayerDrawable {
        val r = dp(radius).toFloat()
        val base = GradientDrawable().apply { setColor(depthColor); cornerRadius = r }
        val face = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom))
            .apply { cornerRadius = r }
        val shine = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x66FFFFFF, 0x00FFFFFF)
        ).apply { cornerRadius = r }
        return LayerDrawable(arrayOf(base, face, shine)).apply {
            setLayerInset(1, 0, 0, 0, dp(depth))
            setLayerInset(2, dp(3), dp(2), dp(3), dp(depth) + dp(26))
        }
    }

    /** Lắc nhẹ (wiggle) qua lại như kiểu rung lắc biểu tượng. */
    private fun wiggle(v: View) {
        ObjectAnimator.ofFloat(v, View.ROTATION, 0f, -4f, 4f, -3f, 3f, -1.5f, 1.5f, 0f).apply {
            duration = 450
            start()
        }
    }

    private fun pressFx(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.96f).scaleY(0.96f).translationY(dp(2).toFloat())
                        .setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).translationY(0f)
                        .setDuration(260).setInterpolator(OvershootInterpolator(2.2f)).start()
                    if (e.action == MotionEvent.ACTION_UP) wiggle(view)
                }
            }
            false
        }
    }

    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(parent: LinearLayout) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = glass(26)
        setPadding(dp(20), dp(20), dp(20), dp(20))
        parent.addView(this, lp(-1, -2, b = 14))
    }

    private fun btn(label: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        stateListAnimator = null
        setTextColor(Color.WHITE)
        setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), 0x66000000)
        background = if (primary)
            face3d(0xFF9DB2FF.toInt(), 0xFF5A6CFF.toInt(), 0xFF2B37A0.toInt(), 18, 5)
        else
            face3d(0x4DFFFFFF, 0x14FFFFFF, 0x40000000, 18, 5)
        setPadding(0, 0, 0, dp(5))
        pressFx(this)
        setOnClickListener { onClick() }
        gated.add(this)
    }

    private fun chipStyle(c: TextView, on: Boolean) {
        c.background = if (on)
            face3d(0xFF9DB2FF.toInt(), 0xFF5A6CFF.toInt(), 0xFF2B37A0.toInt(), 14, 3)
        else glass(14)
        c.setTextColor(if (on) Color.WHITE else SUB)
    }

    private fun tintSwitch(sw: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(ACCENT_LIGHT, 0xFFC4CADA.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x886C8CFF.toInt(), 0x44FFFFFF))
    }

    private fun updateSpeedChips() {
        val sel = prefs.getString("scale", "0.5")
        speedChips.forEachIndexed { i, c ->
            val on = scaleList[i].first == sel
            c.background = if (on)
                face3d(0xFF9DB2FF.toInt(), 0xFF5A6CFF.toInt(), 0xFF2B37A0.toInt(), 14, 3)
            else glass(14)
            c.setTextColor(if (on) Color.WHITE else SUB)
        }
    }

    private fun updateChips() {
        val sel = prefs.getInt("hz", 120)
        chips.forEachIndexed { i, c ->
            val on = hzList[i] == sel
            c.background = if (on)
                face3d(0xFF9DB2FF.toInt(), 0xFF5A6CFF.toInt(), 0xFF2B37A0.toInt(), 14, 3)
            else glass(14)
            c.setTextColor(if (on) Color.WHITE else SUB)
        }
        updateSpeedChips()
    }

    private fun buildUi() {
        // 5 panel riêng, mỗi panel là một tab: 0 Chính, 1 Hiệu năng, 2 Màn hình, 3 Game, 4 Hệ thống
        val panels = List(5) {
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(24), dp(20), dp(20))
            }
        }
        var root: LinearLayout = panels[0]
        listOf(
            Triple("Tăng tốc", "Giải phóng RAM, dọn cache, tối ưu ứng dụng", 0),
            Triple("Hiệu năng", "Tần số quét, hoạt ảnh, chế độ siêu cấp", 1),
            Triple("Màn hình", "Độ phân giải, DPI, hiện tốc độ làm mới", 2),
            Triple("Game", "FPS, trình điều khiển đồ họa, dồn tài nguyên", 3),
            Triple("Hệ thống", "Joyose, pin, nhiệt độ, cập nhật, thống kê", 4)
        ).forEach { (t, sub, i) ->
            panels[i].addView(tv(t, 28f, TEXT, true))
            panels[i].addView(tv(sub, 13f, SUB), lp(-2, -2, t = 2, b = 18))
        }

        // Khung cố định phía trên, luôn hiện ở mọi tab: tên app, tên máy, Shizuku, Fix lag
        val headerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(22)
            setPadding(dp(16), dp(12), dp(16), dp(14))
        }
        val topRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = tv("tđ.exe", 22f, Color.WHITE, true).apply {
            setShadowLayer(dp(8).toFloat(), 0f, dp(3).toFloat(), 0x886C8CFF.toInt())
            post {
                val w = paint.measureText(text.toString())
                paint.shader = LinearGradient(
                    0f, 0f, w, 0f,
                    intArrayOf(Color.WHITE, 0xFFB7C6FF.toInt(), 0xFFD7A8FF.toInt()), null, Shader.TileMode.CLAMP
                )
                invalidate()
            }
        }
        title.setOnClickListener { wiggle(it) }
        topRow.addView(title, lp(0, -2).apply { weight = 1f })
        dot = View(this)
        topRow.addView(dot, lp(dp(8), dp(8), r = 8))
        ObjectAnimator.ofPropertyValuesHolder(
            dot,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.5f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.5f),
            PropertyValuesHolder.ofFloat("alpha", 1f, 0.45f)
        ).apply {
            duration = 1000; repeatMode = android.animation.ValueAnimator.REVERSE
            repeatCount = android.animation.ValueAnimator.INFINITE; start()
        }
        shizukuText = tv("", 12f, TEXT, true)
        topRow.addView(shizukuText)
        headerCard.addView(topRow)

        deviceName = tv(Build.MODEL, 15f, TEXT, true)
        deviceInfo = tv("", 11f, SUB)
        headerCard.addView(deviceName, lp(-2, -2, t = 6))
        headerCard.addView(deviceInfo, lp(-2, -2, t = 1, b = 10))
        loadDevice()

        val fixRow = LinearLayout(this)
        fixRow.addView(btn("Fix lag", true) { confirmFixLag() }, lp(0, dp(50), r = 6).apply { weight = 1.4f })
        fixRow.addView(btn("Hoàn tác", false) { undoFixLag() }, lp(0, dp(50), l = 6).apply { weight = 1f })
        headerCard.addView(fixRow)

        root = panels[4]
        // Thẻ Joyose
        val c2 = card(root)
        c2.addView(tv("Joyose", 18f, TEXT, true))
        c2.addView(tv(pkg, 12f, SUB), lp(-2, -2, b = 14))
        val st = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        st.addView(tv("Trạng thái:  ", 15f, SUB))
        joyoseText = tv("—", 15f, SUB, true)
        st.addView(joyoseText)
        st.setOnClickListener { checkJoyoseStatus(true) }
        c2.addView(st, lp(-1, -2, b = 4))
        c2.addView(tv("Chạm vào dòng trạng thái để kiểm tra lại", 11f, SUB), lp(-2, -2, b = 16))
        val row2 = LinearLayout(this)
        row2.addView(btn("Gỡ Joyose", true) { removeJoyose() }, lp(0, dp(58), r = 6).apply { weight = 1f })
        row2.addView(btn("Cài lại", false) { installJoyose() }, lp(0, dp(58), l = 6).apply { weight = 1f })
        c2.addView(row2)

        // Thẻ Pin và hiệu suất
        val c2b = card(root)
        c2b.addView(tv("Pin và hiệu suất", 18f, TEXT, true))
        c2b.addView(tv(pkg2, 12f, SUB), lp(-2, -2, b = 14))
        val st2 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        st2.addView(tv("Trạng thái:  ", 15f, SUB))
        pkText = tv("—", 15f, SUB, true)
        st2.addView(pkText)
        st2.setOnClickListener { checkPowerStatus(true) }
        c2b.addView(st2, lp(-1, -2, b = 12))
        c2b.addView(
            tv("Gỡ app này có thể mở khóa tần số quét cao hơn, nhưng mất tiết kiệm pin và quản lý chạy nền. " +
                "Sau khi gỡ, bấm Xác minh thực tế để xem số Hz thật.", 12f, SUB),
            lp(-2, -2, b = 16)
        )
        val row2b = LinearLayout(this)
        row2b.addView(btn("Gỡ", true) { confirmRemovePower() }, lp(0, dp(58), r = 6).apply { weight = 1f })
        row2b.addView(btn("Cài lại", false) { installPower() }, lp(0, dp(58), l = 6).apply { weight = 1f })
        c2b.addView(row2b)

        root = panels[2]
        // Thẻ độ phân giải và DPI
        val cd = card(root)
        cd.addView(tv("Độ phân giải và DPI", 18f, TEXT, true))
        dpiInfo = tv("Đang đọc…", 12f, SUB)
        cd.addView(dpiInfo, lp(-2, -2, t = 2, b = 14))

        val etRow = LinearLayout(this)
        fun col(label: String): android.widget.EditText {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            val et = android.widget.EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                gravity = Gravity.CENTER
                setTextColor(TEXT)
                setHintTextColor(SUB)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                background = glass(14)
                setPadding(dp(8), dp(12), dp(8), dp(12))
                isSingleLine = true
            }
            box.addView(et, lp(-1, -2))
            box.addView(tv(label, 11f, SUB), lp(-2, -2, t = 4))
            etRow.addView(box, lp(0, -2, l = 4, r = 4).apply { weight = 1f })
            return et
        }
        etW = col("Rộng")
        etH = col("Cao")
        etS = col("dp (như Cài đặt)")
        cd.addView(etRow, lp(-1, -2, b = 12))

        val swRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val swLeft = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        swLeft.addView(tv("DPI tương ứng (tự tính)", 14f, TEXT, true))
        swLeft.addView(tv("Tự đổi theo ô dp ở trên", 11f, SUB), lp(-2, -2, t = 2))
        swRow.addView(swLeft, lp(0, -2).apply { weight = 1f })
        etD = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            gravity = Gravity.CENTER
            setTextColor(TEXT)
            setHintTextColor(SUB)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            background = glass(14)
            setPadding(dp(8), dp(10), dp(8), dp(10))
            isSingleLine = true
        }
        swRow.addView(etD, lp(dp(110), -2))
        cd.addView(swRow, lp(-1, -2, b = 12))

        val lockRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        lockRow.addView(tv("Khóa tỉ lệ (nên bật)", 14f, TEXT, true), lp(0, -2).apply { weight = 1f })
        lockSwitch = Switch(this).apply { tintSwitch(this); isChecked = true }
        lockRow.addView(lockSwitch)
        cd.addView(lockRow, lp(-1, -2, b = 14))

        etW.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (fieldsBusy) return
                val w = s?.toString()?.toIntOrNull()
                if (w != null && lockSwitch.isChecked && physW != 0) {
                    fieldsBusy = true
                    etH.setText(Math.round(w * physH.toDouble() / physW).toString())
                    fieldsBusy = false
                }
                dpiFromSw()
            }
        })
        etH.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (fieldsBusy) return
                val h = s?.toString()?.toIntOrNull()
                if (h != null && lockSwitch.isChecked && physH != 0) {
                    fieldsBusy = true
                    etW.setText(Math.round(h * physW.toDouble() / physH).toString())
                    fieldsBusy = false
                }
                dpiFromSw()
            }
        })
        // Sửa DPI thì dp đổi theo (nghịch), sửa dp thì DPI đổi theo
        etD.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (!fieldsBusy) { lastEdit = 'D'; swFromDpi() }
            }
        })
        etS.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (!fieldsBusy) { lastEdit = 'S'; dpiFromSw() }
            }
        })

        val rowd = LinearLayout(this)
        rowd.addView(btn("Đặt lại gốc", false) { resetDisplay() }, lp(0, dp(58), r = 6).apply { weight = 1f })
        rowd.addView(btn("Áp dụng", true) { applyDisplay() }, lp(0, dp(58), l = 6).apply { weight = 1f })
        cd.addView(rowd)
        cd.addView(
            tv("Nên giữ Khóa tỉ lệ bật: sửa Rộng thì Cao tự đổi theo. Nhập số dp bạn muốn thấy trong Cài đặt (Độ rộng nhỏ nhất), DPI tự tính. Đổi Rộng/Cao thì dp giữ nguyên. " +
                "Sau khi áp dụng bạn có 15 giây để xác nhận, nếu không máy tự hoàn lại.", 11f, SUB),
            lp(-2, -2, t = 14)
        )

        root = panels[1]
        // Thẻ hiệu năng cao
        val c3 = card(root)
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(tv("Khóa tần số quét", 18f, TEXT, true))
        left.addView(tv("Tắt công tắc là khôi phục lại như cũ", 12f, SUB), lp(-2, -2, t = 2))
        head.addView(left, lp(0, -2).apply { weight = 1f })
        perfSwitch = Switch(this).apply {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(ACCENT_LIGHT, 0xFFC4CADA.toInt()))
            trackTintList = ColorStateList(states, intArrayOf(0x886C8CFF.toInt(), 0x44FFFFFF))
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                if (on) enablePerf() else restorePerf()
            }
        }
        gated.add(perfSwitch)
        head.addView(perfSwitch)
        c3.addView(head)
        c3.addView(tv("Tần số quét", 13f, SUB), lp(-2, -2, t = 18, b = 8))
        val chipRow = LinearLayout(this)
        hzList.forEach { hz ->
            val c = tv("${hz}Hz", 15f, SUB, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                pressFx(this)
                setOnClickListener {
                    prefs.edit().putInt("hz", hz).apply()
                    updateChips()
                    if (prefs.getBoolean("active", false)) enablePerf()
                }
            }
            chips.add(c); gated.add(c)
            chipRow.addView(c, lp(-2, -2, r = 8))
        }
        c3.addView(chipRow)
        c3.addView(btn("Xác minh thực tế", false) { verify() }, lp(-1, dp(58), t = 16))
        c3.addView(
            tv("Khóa tần số quét ở mức bạn chọn. " +
                "Game vẫn quyết định số khung hình thực tế, nên màn hình chỉ lên 120Hz khi game xuất đủ 120 FPS.", 11f, SUB),
            lp(-2, -2, t = 16)
        )

        root = panels[0]
        // Thẻ tăng tốc máy
        val c8 = card(root)
        c8.addView(tv("Tăng tốc máy", 18f, TEXT, true))
        c8.addView(
            tv("Không tăng sức mạnh phần cứng, nhưng giải phóng tài nguyên và tối ưu ứng dụng để máy mượt hơn. " +
                "Mỗi nút hiện số liệu trước và sau để bạn tự kiểm chứng.", 12f, SUB),
            lp(-2, -2, t = 2, b = 14)
        )
        c8.addView(btn("Giải phóng RAM", true) { freeRam() }, lp(-1, dp(58)))
        c8.addView(btn("Dọn bộ nhớ đệm", false) { trimCaches() }, lp(-1, dp(58), t = 10))
        c8.addView(btn("Tối ưu ứng dụng (mở app nhanh hơn)", false) { compileApps() }, lp(-1, dp(58), t = 10))
        c8.addView(
            tv("Tối ưu ứng dụng mất vài phút và hao pin, nên cắm sạc. Tác dụng thấy rõ nhất ở tốc độ mở app.", 11f, SUB),
            lp(-2, -2, t = 14)
        )

        root = panels[1]
        // Thẻ Speed mode
        val c5 = card(root)
        val head2 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left2.addView(tv("Tăng tốc hoạt ảnh", 18f, TEXT, true))
        left2.addView(tv("Rút ngắn hoạt ảnh — tắt là khôi phục", 12f, SUB), lp(-2, -2, t = 2))
        head2.addView(left2, lp(0, -2).apply { weight = 1f })
        speedSwitch = Switch(this).apply {
            tintSwitch(this)
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                if (on) enableSpeed() else restoreSpeed()
            }
        }
        gated.add(speedSwitch)
        head2.addView(speedSwitch)
        c5.addView(head2)
        c5.addView(tv("Tốc độ hoạt ảnh", 13f, SUB), lp(-2, -2, t = 18, b = 8))
        val scaleRow = LinearLayout(this)
        scaleList.forEach { (value, label) ->
            val c = tv(label, 15f, SUB, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                pressFx(this)
                setOnClickListener {
                    prefs.edit().putString("scale", value).apply()
                    updateSpeedChips()
                    if (prefs.getBoolean("speed", false)) enableSpeed()
                }
            }
            speedChips.add(c); gated.add(c)
            scaleRow.addView(c, lp(-2, -2, r = 8))
        }
        c5.addView(scaleRow)
        c5.addView(
            tv("Chỉnh 3 giá trị: window_animation_scale, transition_animation_scale, animator_duration_scale. " +
                "Chỉ làm giao diện chuyển cảnh nhanh hơn, không tăng sức mạnh xử lý.", 11f, SUB),
            lp(-2, -2, t = 16)
        )

        // Thẻ speed_mode_enable
        val c6 = card(root)
        val head3 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left3 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left3.addView(tv("Chế độ siêu cấp", 18f, TEXT, true))
        left3.addView(tv("Giống mục trong Tùy chọn nhà phát triển", 12f, SUB), lp(-2, -2, t = 2))
        head3.addView(left3, lp(0, -2).apply { weight = 1f })
        flagSwitch = Switch(this).apply {
            tintSwitch(this)
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                setSpeedFlag(on)
            }
        }
        gated.add(flagSwitch)
        head3.addView(flagSwitch)
        c6.addView(head3)
        c6.addView(
            tv("Ghi cả speed_mode (System) và speed_mode_enable (Secure): bật = 1, tắt = 0, rồi đọc lại. " +
                "Sau khi bật, vào Tùy chọn nhà phát triển để thấy công tắc Chế độ siêu cấp đổi theo.", 11f, SUB),
            lp(-2, -2, t = 14)
        )

        root = panels[4]
        // Thẻ thông báo nhiệt độ
        val c7 = card(root)
        val head4 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left4 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left4.addView(tv("Thông báo nhiệt độ", 18f, TEXT, true))
        left4.addView(tv("Hiện số độ C ngay trên thanh trạng thái", 12f, SUB), lp(-2, -2, t = 2))
        head4.addView(left4, lp(0, -2).apply { weight = 1f })
        tempSwitch = Switch(this).apply {
            tintSwitch(this)
            isChecked = prefs.getBoolean("temp", false)
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                if (on) {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
                    } else {
                        prefs.edit().putBoolean("temp", true).apply(); startTemp()
                    }
                } else {
                    prefs.edit().putBoolean("temp", false).apply(); stopTemp()
                }
            }
        }
        head4.addView(tempSwitch)
        c7.addView(head4)
        c7.addView(
            tv("Đo nhiệt độ pin (không cần Shizuku). Nếu thông báo biến mất, vào Cài đặt → Ứng dụng → tđ.exe " +
                "→ Tiết kiệm pin → chọn Không hạn chế.", 11f, SUB),
            lp(-2, -2, t = 14)
        )

        root = panels[3]
        // Thẻ tắt FPS mặc định của game
        val c9 = card(root)
        val head5 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val left5 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left5.addView(tv("Tắt FPS mặc định của game", 18f, TEXT, true))
        left5.addView(tv("Bỏ giới hạn 60Hz cho trò chơi", 12f, SUB), lp(-2, -2, t = 2))
        head5.addView(left5, lp(0, -2).apply { weight = 1f })
        fpsSwitch = Switch(this).apply {
            tintSwitch(this)
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                setGameFps(on)
            }
        }
        gated.add(fpsSwitch)
        head5.addView(fpsSwitch)
        c9.addView(head5)
        c9.addView(
            tv("Giống mục \"Tắt tốc độ khung hình mặc định cho trò chơi\" trong Tùy chọn nhà phát triển. " +
                "Giá trị mất sau khi khởi động lại máy nên cần bật lại. Nếu máy chặn lệnh, app báo ❌ — khi đó bấm nút dưới để bật tay.", 11f, SUB),
            lp(-2, -2, t = 14, b = 12)
        )
        val devBtn = btn("Mở Tùy chọn nhà phát triển", false) {
            startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        }
        gated.remove(devBtn)
        c9.addView(devBtn, lp(-1, dp(56)))

        root = panels[2]
        // Thẻ hiện tốc độ làm mới: lớp phủ nổi của chính app nên quay màn hình vẫn thấy
        val chz = card(root)
        val headz = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val leftz = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        leftz.addView(tv("Hiện tốc độ làm mới", 18f, TEXT, true))
        leftz.addView(tv("Số Hz nổi trên mọi app, quay màn vẫn thấy", 12f, SUB), lp(-2, -2, t = 2))
        headz.addView(leftz, lp(0, -2).apply { weight = 1f })
        hzSwitch = Switch(this).apply {
            tintSwitch(this)
            isChecked = prefs.getBoolean("showhz", false)
            setOnCheckedChangeListener { _, on ->
                if (suppress) return@setOnCheckedChangeListener
                toggleOverlay(on)
            }
        }
        headz.addView(hzSwitch)
        chz.addView(headz)

        chz.addView(tv("Vị trí", 13f, SUB), lp(-2, -2, t = 16, b = 8))
        val posRow = LinearLayout(this)
        listOf("↖", "↗", "↙", "↘").forEachIndexed { i, label ->
            val c = tv(label, 20f, SUB, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(22), dp(10), dp(22), dp(10))
                pressFx(this)
                setOnClickListener {
                    prefs.edit().putInt("ov_pos", i).apply()
                    updateOverlayChips()
                    reloadOverlay()
                }
            }
            ovPosChips.add(c)
            posRow.addView(c, lp(-2, -2, r = 8))
        }
        chz.addView(posRow)

        chz.addView(tv("Cỡ chữ", 13f, SUB), lp(-2, -2, t = 14, b = 8))
        val sizeRow = LinearLayout(this)
        listOf("Nhỏ", "Vừa", "Lớn").forEachIndexed { i, label ->
            val c = tv(label, 15f, SUB, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                pressFx(this)
                setOnClickListener {
                    prefs.edit().putInt("ov_size", i).apply()
                    updateOverlayChips()
                    reloadOverlay()
                }
            }
            ovSizeChips.add(c)
            sizeRow.addView(c, lp(-2, -2, r = 8))
        }
        chz.addView(sizeRow)
        updateOverlayChips()

        chz.addView(
            tv("Đây là lớp phủ của chính tđ.exe nên vẫn hiện khi quay màn hình, không giống lớp phủ có sẵn của Tùy chọn " +
                "nhà phát triển. Lần đầu cần cấp quyền \"Hiển thị trên ứng dụng khác\" (app sẽ thử cấp qua Shizuku). " +
                "Mất sau khi khởi động lại máy.", 11f, SUB),
            lp(-2, -2, t = 16)
        )
        val devBtnZ = btn("Mở Tùy chọn nhà phát triển", false) {
            startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        }
        gated.remove(devBtnZ)
        chz.addView(devBtnZ, lp(-1, dp(52), t = 12))

        root = panels[3]
        // Thẻ trình điều khiển đồ họa
        val c10 = card(root)
        c10.addView(tv("Trình điều khiển đồ họa", 18f, TEXT, true))
        c10.addView(tv("Đặt riêng cho từng bản Free Fire", 12f, SUB), lp(-2, -2, t = 2, b = 4))
        games.forEach { (pk, name) ->
            c10.addView(tv(name, 15f, TEXT, true), lp(-2, -2, t = 14))
            val stv = tv("Đang kiểm tra…", 11f, SUB)
            driverStatus[pk] = stv
            c10.addView(stv, lp(-2, -2, t = 2, b = 8))
            val row = LinearLayout(this)
            val chipsForGame = mutableListOf<TextView>()
            listOf("Mặc định" to false, "Hệ thống" to true).forEach { (label, sys) ->
                val c = tv(label, 14f, SUB, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(18), dp(11), dp(18), dp(11))
                    pressFx(this)
                    setOnClickListener { setDriver(pk, name, sys) }
                }
                chipStyle(c, false)
                chipsForGame.add(c); gated.add(c)
                row.addView(c, lp(-2, -2, r = 8))
            }
            driverChips[pk] = chipsForGame
            c10.addView(row)
        }
        c10.addView(
            tv("Giống mục Các lựa chọn ưu tiên về trình điều khiển đồ họa. Sau khi đổi, thoát hẳn game rồi mở lại.", 11f, SUB),
            lp(-2, -2, t = 16)
        )

        // Thẻ dồn tài nguyên cho game
        val cg = card(root)
        cg.addView(tv("Dồn tài nguyên cho game", 18f, TEXT, true))
        cg.addView(
            tv("Bật chế độ Game Hiệu năng, miễn hạn chế pin, ưu tiên chạy và giải phóng RAM cho " +
                "Free Fire và Free Fire MAX đã cài trên máy.", 12f, SUB),
            lp(-2, -2, t = 2, b = 14)
        )
        cg.addView(btn("Dồn tài nguyên vào game", true) { boostGames() }, lp(-1, dp(58)))
        cg.addView(btn("Hoàn lại", false) { undoBoost() }, lp(-1, dp(52), t = 10))
        cg.addView(
            tv("Không có lệnh nào ép CPU hay GPU chạy riêng cho game nếu máy không root. Các bước này giải phóng RAM " +
                "và nhờ hệ thống ưu tiên game. Hiệu quả tùy máy, bạn xem số RAM trước và sau để biết.", 11f, SUB),
            lp(-2, -2, t = 14)
        )

        root = panels[4]
        // Thẻ dò khóa
        val c11 = card(root)
        c11.addView(tv("Dò khóa hệ thống", 18f, TEXT, true))
        c11.addView(
            tv("Dùng khi một mục không chạy: chụp trạng thái, tự đổi bằng tay trong Cài đặt, rồi so sánh để biết " +
                "Cài đặt thực sự thay đổi khóa nào. Gửi kết quả cho tôi để sửa app.", 12f, SUB),
            lp(-2, -2, t = 2, b = 14)
        )
        c11.addView(btn("1. Chụp trạng thái", false) { takeSnap() }, lp(-1, dp(56)))
        c11.addView(btn("2. So sánh sau khi tự đổi", true) { compareSnap() }, lp(-1, dp(56), t = 10))

        // Thẻ thống kê ẩn danh
        if (BuildConfig.ANALYTICS_URL.isNotBlank()) {
            val cp = card(root)
            val headp = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val leftp = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            leftp.addView(tv("Thống kê ẩn danh", 18f, TEXT, true))
            leftp.addView(tv("Chỉ gửi mã ngẫu nhiên và số phiên bản", 12f, SUB), lp(-2, -2, t = 2))
            headp.addView(leftp, lp(0, -2).apply { weight = 1f })
            privacySwitch = Switch(this).apply {
                tintSwitch(this)
                isChecked = prefs.getBoolean("analytics", false)
                setOnCheckedChangeListener { _, on ->
                    if (suppress) return@setOnCheckedChangeListener
                    prefs.edit().putBoolean("analytics", on).apply()
                    if (on) pingAnalytics()
                }
            }
            headp.addView(privacySwitch)
            cp.addView(headp)
            pingStatus = tv(prefs.getString("last_ping", "Chưa gửi lần nào") ?: "", 11f, SUB)
            cp.addView(pingStatus, lp(-2, -2, t = 12, b = 4))
            cp.addView(tv("Địa chỉ đã nhúng: …" + BuildConfig.ANALYTICS_URL.takeLast(26), 10f, SUB), lp(-2, -2, b = 10))
            val testBtn = btn("Gửi thử ngay", false) {
                if (prefs.getBoolean("analytics", false)) {
                    pingStatus?.text = "Đang gửi…"
                    pingAnalytics()
                } else {
                    pingStatus?.text = "Hãy bật công tắc Thống kê ẩn danh trước"
                }
            }
            gated.remove(testBtn)
            cp.addView(testBtn, lp(-1, dp(50)))
        }

        // Thẻ cập nhật
        val cu = card(root)
        cu.addView(tv("Cập nhật ứng dụng", 18f, TEXT, true))
        cu.addView(tv("Đang dùng bản v${currentVersionCode()} • lấy bản mới từ GitHub Release", 12f, SUB), lp(-2, -2, t = 2, b = 14))
        val upBtn = btn("Kiểm tra cập nhật", true) { checkUpdate() }
        gated.remove(upBtn)
        cu.addView(upBtn, lp(-1, dp(56)))

        // Thanh kết quả cố định phía trên thanh tab (chạm tiêu đề để đổi cỡ: nhỏ, lớn, ẩn)
        log = tv("Chưa có thao tác nào", 12f, TEXT).apply { typeface = Typeface.MONOSPACE }
        val screenH = resources.displayMetrics.heightPixels
        val resultScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            setPadding(dp(16), 0, dp(16), dp(10))
            clipToPadding = false
            addView(log)
        }
        val resultHeader = tv("Kết quả  ▾", 12f, SUB, true).apply { setPadding(dp(16), dp(10), dp(16), dp(6)) }
        val resultPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(18)
            addView(resultHeader)
            addView(resultScroll, LinearLayout.LayoutParams(-1, (screenH * 0.13).toInt()))
        }
        resultPanelRef = resultPanel
        val resultHeights = intArrayOf((screenH * 0.13).toInt(), (screenH * 0.42).toInt(), 0)
        val resultTitles = arrayOf("Kết quả  ▾", "Kết quả  ▴", "Kết quả  ▸")
        var resultState = 0
        resultHeader.setOnClickListener {
            resultState = (resultState + 1) % 3
            val lpp = resultScroll.layoutParams
            lpp.height = resultHeights[resultState]
            resultScroll.layoutParams = lpp
            resultScroll.visibility = if (resultState == 2) View.GONE else View.VISIBLE
            resultHeader.text = resultTitles[resultState]
        }

        // Các tab
        val scrolls = panels.map { pn ->
            ScrollView(this).apply {
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                visibility = View.GONE
                addView(pn)
            }
        }
        val content = FrameLayout(this)
        scrolls.forEach { content.addView(it, FrameLayout.LayoutParams(-1, -1)) }

        val tabNames = listOf("Tăng tốc", "Hiệu năng", "Màn hình", "Game", "Hệ thống")
        val tabIcons = listOf("🚀", "⚡", "▭", "🎮", "⚙")
        val tabItems = mutableListOf<LinearLayout>()
        var current = -1
        fun showTab(i: Int) {
            if (i == current) return
            current = i
            scrolls.forEachIndexed { k, sv -> sv.visibility = if (k == i) View.VISIBLE else View.GONE }
            val sv = scrolls[i]
            sv.alpha = 0f
            sv.translationY = dp(14).toFloat()
            sv.animate().alpha(1f).translationY(0f).setDuration(260)
                .setInterpolator(DecelerateInterpolator()).start()
            tabItems.forEachIndexed { k, item ->
                val on = k == i
                (item.getChildAt(0) as TextView).setTextColor(if (on) ACCENT_LIGHT else SUB)
                (item.getChildAt(1) as TextView).setTextColor(if (on) Color.WHITE else SUB)
                item.background = if (on) glass(16) else null
            }
        }

        val tabBar = LinearLayout(this).apply {
            background = glass(22)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        tabNames.forEachIndexed { i, name ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, dp(6))
                addView(tv(tabIcons[i], 18f, SUB).apply { gravity = Gravity.CENTER })
                addView(tv(name, 10f, SUB, true).apply { gravity = Gravity.CENTER })
                setOnClickListener { showTab(i) }
            }
            tabItems.add(item)
            tabBar.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }

        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(headerCard, lp(-1, -2).apply { setMargins(dp(14), dp(10), dp(14), dp(6)) })
        column.addView(resultPanel, lp(-1, -2).apply { setMargins(dp(14), 0, dp(14), dp(4)) })
        column.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        column.addView(tabBar, lp(-1, -2).apply { setMargins(dp(14), dp(4), dp(14), dp(10)) })

        val frame = FrameLayout(this)
        frame.addView(OrbView(this), FrameLayout.LayoutParams(-1, -1))
        frame.addView(column, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        showTab(0)
    }
}
