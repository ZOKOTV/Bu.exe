package com.joyose.tool

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

/** Nền động: các quầng sáng màu trôi chậm phía sau lớp kính. */
class OrbView(context: Context) : View(context) {

    private val base = 0xFF080A12.toInt()
    private val rgb = intArrayOf(0x6C8CFF, 0xB065FF, 0x2DD4BF)
    private val radii = FloatArray(3)
    private val shaders = arrayOfNulls<RadialGradient>(3)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f

    private val anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 22000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val scale = floatArrayOf(0.75f, 0.70f, 0.80f)
        for (i in 0..2) {
            radii[i] = w * scale[i]
            val c = rgb[i]
            shaders[i] = RadialGradient(
                0f, 0f, radii[i],
                intArrayOf((0x70 shl 24) or c, (0x00 shl 24) or c), null, Shader.TileMode.CLAMP
            )
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        c.drawColor(base)
        val w = width.toFloat(); val h = height.toFloat()
        orb(c, 0, w * (0.18f + 0.10f * sin(t)), h * (0.14f + 0.05f * cos(t)))
        orb(c, 1, w * (0.92f - 0.10f * cos(t)), h * (0.52f + 0.06f * sin(t)))
        orb(c, 2, w * (0.28f + 0.08f * sin(t + 2f)), h * (0.92f - 0.05f * cos(t)))
    }

    private fun orb(c: Canvas, i: Int, cx: Float, cy: Float) {
        paint.shader = shaders[i]
        c.save(); c.translate(cx, cy)
        c.drawCircle(0f, 0f, radii[i], paint)
        c.restore()
    }
}
