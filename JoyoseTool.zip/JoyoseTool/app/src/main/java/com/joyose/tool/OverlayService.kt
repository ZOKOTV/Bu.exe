package com.joyose.tool

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/**
 * Hiện tốc độ làm mới (Hz) của màn hình. Hai kiểu (pref "ov_mode"):
 *  0 = trên thanh thông báo: biểu tượng trạng thái là con số Hz, KHÔNG vẽ gì đè lên game, không cần quyền vẽ đè.
 *  1 = nổi trên màn hình: cửa sổ riêng của app, thấy cả trong game và trong video quay màn hình.
 */
class OverlayService : Service() {

    companion object {
        @Volatile var running = false
        private const val NOTIF_ID = 2
        private const val CHANNEL = "overlay_hz"
    }

    private lateinit var wm: WindowManager
    private lateinit var nm: NotificationManager
    private var view: TextView? = null
    private var mode = 0
    private var lastHz = -1
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 500)
        }
    }

    private val listener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { update() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        nm = getSystemService(NotificationManager::class.java)

        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Hiện tốc độ làm mới", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val n = notif(null)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }

        build()
        getSystemService(DisplayManager::class.java).registerDisplayListener(listener, handler)
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "reload") build()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(listener) } catch (_: Throwable) {}
        removeView()
        super.onDestroy()
    }

    private fun removeView() {
        view?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        view = null
    }

    private fun currentHz(): Int {
        val disp = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY) ?: return -1
        return Math.round(disp.refreshRate)
    }

    private fun build() {
        removeView()
        lastHz = -1
        val prefs = getSharedPreferences("joyose_tool", MODE_PRIVATE)
        mode = prefs.getInt("ov_mode", 0)
        // Kiểu nổi cần quyền vẽ đè; chưa có thì tạm dùng kiểu thanh thông báo
        if (mode == 1 && !Settings.canDrawOverlays(this)) mode = 0

        if (mode == 0) {
            update()
            return
        }

        nm.notify(NOTIF_ID, notif(null))
        val pos = prefs.getInt("ov_pos", 1).coerceIn(0, 3)          // 0 trên trái, 1 trên phải, 2 dưới trái, 3 dưới phải
        val sp = intArrayOf(12, 16, 22)[prefs.getInt("ov_size", 1).coerceIn(0, 2)]
        val d = resources.displayMetrics.density

        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = sp.toFloat()
            typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(3f, 0f, 1f, Color.BLACK)
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
            background = GradientDrawable().apply {
                setColor(0x99000000.toInt())
                cornerRadius = 10 * d
            }
            text = "-- Hz"
        }

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = when (pos) {
            0 -> Gravity.TOP or Gravity.START
            1 -> Gravity.TOP or Gravity.END
            2 -> Gravity.BOTTOM or Gravity.START
            else -> Gravity.BOTTOM or Gravity.END
        }
        lp.x = (10 * d).toInt()
        lp.y = (if (pos < 2) 30 else 10).times(d).toInt()
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(tv, lp)
            view = tv
        } catch (e: Throwable) {
            mode = 0
        }
        update()
    }

    private fun update() {
        val hz = currentHz()
        if (hz < 0) return
        if (mode == 0) {
            if (hz != lastHz) {
                lastHz = hz
                nm.notify(NOTIF_ID, notif(hz))
            }
        } else {
            val v = view ?: return
            val t = "$hz Hz"
            if (v.text.toString() != t) v.text = t
        }
    }

    /** hz = null: thông báo chung; có số: biểu tượng thanh trạng thái là con số Hz. */
    private fun notif(hz: Int?): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
        else Notification.Builder(this)
        val icon = if (hz != null) Icon.createWithBitmap(hzIcon(hz))
        else Icon.createWithResource(this, android.R.drawable.ic_menu_view)
        return b.setSmallIcon(icon)
            .setContentTitle(if (hz != null) "Tốc độ làm mới: $hz Hz" else "Đang hiện tốc độ làm mới")
            .setContentText("Chạm để mở tđ.exe. Tắt công tắc trong app để ẩn.")
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .build()
    }

    private fun hzIcon(hz: Int): Bitmap {
        val s = 96
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
            textSize = 80f
        }
        val txt = hz.toString()
        while (p.measureText(txt) > s - 2 && p.textSize > 20f) p.textSize -= 2f
        c.drawText(txt, s / 2f, s / 2f - (p.descent() + p.ascent()) / 2f, p)
        return bmp
    }
}
