package com.joyose.tool

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/**
 * Lớp phủ nổi hiện tốc độ làm mới (Hz) của màn hình, vẽ trên mọi ứng dụng kể cả game.
 * Đây là cửa sổ của chính app nên khi quay màn hình vẫn được ghi lại
 * (khác với lớp phủ của Tùy chọn nhà phát triển).
 */
class OverlayService : Service() {

    companion object {
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private var view: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 500)
        }
    }

    private val listener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { update() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("overlay_hz", "Hiện tốc độ làm mới", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "overlay_hz")
        else Notification.Builder(this)
        val n = b.setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Đang hiện tốc độ làm mới")
            .setContentText("Chạm để mở tđ.exe. Tắt công tắc trong app để ẩn.")
            .setContentIntent(pi)
            .setOngoing(true)
            .setShowWhen(false)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(2, n)
        }

        build()
        getSystemService(DisplayManager::class.java).registerDisplayListener(listener, handler)
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "reload") build()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { getSystemService(DisplayManager::class.java).unregisterDisplayListener(listener) } catch (_: Throwable) {}
        removeView()
        super.onDestroy()
    }

    private fun removeView() {
        view?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        view = null
    }

    private fun build() {
        removeView()
        val prefs = getSharedPreferences("joyose_tool", MODE_PRIVATE)
        val pos = prefs.getInt("ov_pos", 1).coerceIn(0, 3)          // 0 trên trái, 1 trên phải, 2 dưới trái, 3 dưới phải
        val sp = intArrayOf(12, 16, 22)[prefs.getInt("ov_size", 1).coerceIn(0, 2)]
        val d = resources.displayMetrics.density

        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = sp.toFloat()
            typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(3f, 0f, 1f, Color.BLACK)
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
            background = GradientDrawable().apply {
                setColor(0x99000000.toInt())
                cornerRadius = 10 * d
            }
            text = "-- Hz"
        }

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = when (pos) {
            0 -> Gravity.TOP or Gravity.START
            1 -> Gravity.TOP or Gravity.END
            2 -> Gravity.BOTTOM or Gravity.START
            else -> Gravity.BOTTOM or Gravity.END
        }
        lp.x = (10 * d).toInt()
        lp.y = (if (pos < 2) 30 else 10).times(d).toInt()
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(tv, lp)
        view = tv
        update()
    }

    private fun update() {
        val v = view ?: return
        val disp = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY) ?: return
        val t = "${Math.round(disp.refreshRate)} Hz"
        if (v.text.toString() != t) v.text = t
    }
}
