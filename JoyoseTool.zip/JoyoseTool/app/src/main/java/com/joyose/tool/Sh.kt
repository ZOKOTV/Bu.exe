package com.joyose.tool

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Chạy lệnh shell qua Shizuku (dùng cho tiện ích, không cần mở app). */
object Sh {
    fun ready(): Boolean {
        for (n in 0 until 30) {
            if (Shizuku.pingBinder()) {
                return try {
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                } catch (e: Throwable) { false }
            }
            Thread.sleep(100)
        }
        return false
    }

    fun run(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }
}
