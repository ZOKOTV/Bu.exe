package com.joyose.tool

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.provider.Settings
import android.widget.RemoteViews
import java.util.Locale

/** Tiện ích màn hình chính: nhiệt độ pin + 2 nút nhanh. */
class TdWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetUi.render(context)
    }

    companion object {
        const val ACTION_SUPER = "com.joyose.tool.WIDGET_SUPER"
        const val ACTION_RAM = "com.joyose.tool.WIDGET_RAM"
        const val ACTION_REFRESH = "com.joyose.tool.WIDGET_REFRESH"
    }
}

object WidgetUi {

    private fun action(ctx: Context, act: String): PendingIntent {
        val i = Intent(ctx, WidgetAction::class.java).setAction(act)
        return PendingIntent.getBroadcast(ctx, act.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun memAvailableMb(): Long = try {
        java.io.File("/proc/meminfo").readLines().firstOrNull { it.startsWith("MemAvailable:") }
            ?.replace(Regex("[^0-9]"), "")?.toLongOrNull()?.div(1024) ?: 0L
    } catch (e: Throwable) { 0L }

    fun render(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, TdWidget::class.java))
        if (ids.isEmpty()) return

        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val on = try {
            Settings.System.getInt(ctx.contentResolver, "speed_mode", 0) == 1 &&
                Settings.Secure.getInt(ctx.contentResolver, "speed_mode_enable", 0) == 1
        } catch (e: Throwable) {
            ctx.getSharedPreferences("joyose_tool", Context.MODE_PRIVATE).getBoolean("speedflag", false)
        }

        val rv = RemoteViews(ctx.packageName, R.layout.widget_td)
        rv.setTextViewText(R.id.w_temp, String.format(Locale.US, "%.1f°C", t))
        rv.setTextViewText(R.id.w_sub, "Pin $level% • RAM trống ${memAvailableMb()} MB")
        rv.setTextViewText(R.id.w_super, if (on) "Siêu cấp: BẬT" else "Siêu cấp: TẮT")

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.w_temp, open)
        rv.setOnClickPendingIntent(R.id.w_sub, action(ctx, TdWidget.ACTION_REFRESH))
        rv.setOnClickPendingIntent(R.id.w_super, action(ctx, TdWidget.ACTION_SUPER))
        rv.setOnClickPendingIntent(R.id.w_ram, action(ctx, TdWidget.ACTION_RAM))
        mgr.updateAppWidget(ids, rv)
    }
}
