package com.joyose.tool

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import java.util.Locale

/** Hiện nhiệt độ pin ngay trên thanh trạng thái (biểu tượng là con số) và trong thông báo. */
class TempService : Service() {

    private val channelId = "temp_monitor"
    private val notifId = 1

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            getSystemService(NotificationManager::class.java).notify(notifId, build(i))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "Nhiệt độ pin", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val sticky = registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val n = build(sticky)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(notifId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(notifId, n)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun build(i: Intent?): Notification {
        val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val volt = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
        else Notification.Builder(this)
        return b.setSmallIcon(Icon.createWithBitmap(tempIcon(t)))
            .setContentTitle(String.format(Locale.US, "Nhiệt độ pin: %.1f°C", t))
            .setContentText("Pin $level%" + (if (charging) " • đang sạc" else "") + " • ${volt}mV")
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .build()
    }

    private fun tempIcon(t: Double): Bitmap {
        val s = 96
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
            textSize = 80f
        }
        val txt = Math.round(t).toString()
        while (p.measureText(txt) > s - 4 && p.textSize > 20f) p.textSize -= 2f
        val y = s / 2f - (p.descent() + p.ascent()) / 2f
        c.drawText(txt, s / 2f, y, p)
        return bmp
    }
}
