package com.joyose.tool

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/** Nhận thao tác bấm từ tiện ích (không xuất ra ngoài app). */
class WidgetAction : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        val app = ctx.applicationContext
        val act = intent.action
        Thread {
            try {
                if (act == TdWidget.ACTION_REFRESH) {
                    // chỉ vẽ lại ở finally
                } else if (!Sh.ready()) {
                    toast(app, "Shizuku chưa sẵn sàng — mở Shizuku rồi thử lại")
                } else when (act) {
                    TdWidget.ACTION_SUPER -> toggleSuper(app)
                    TdWidget.ACTION_RAM -> freeRam(app)
                    else -> {}
                }
            } catch (e: Throwable) {
                toast(app, "Lỗi: ${e.message}")
            } finally {
                WidgetUi.render(app)
                pending.finish()
            }
        }.start()
    }

    private fun toggleSuper(ctx: Context) {
        val a = Sh.run("settings get system speed_mode")
        val b = Sh.run("settings get secure speed_mode_enable")
        val v = if (a == "1" && b == "1") "0" else "1"
        Sh.run("settings put system speed_mode $v")
        Sh.run("settings put secure speed_mode_enable $v")
        val ok = Sh.run("settings get system speed_mode") == v &&
            Sh.run("settings get secure speed_mode_enable") == v
        ctx.getSharedPreferences("joyose_tool", Context.MODE_PRIVATE)
            .edit().putBoolean("speedflag", ok && v == "1").apply()
        toast(ctx, if (ok) "Chế độ siêu cấp: " + (if (v == "1") "BẬT" else "TẮT") else "Không ghi được — hệ thống chặn")
    }

    private fun freeRam(ctx: Context) {
        Sh.run("pm trim-caches 999G")
        toast(ctx, "Đã dọn bộ nhớ đệm")
    }

    private fun toast(ctx: Context, msg: String) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
    }
}
